# 🎮 Disney Infinity 3.0 PC — Local Co-Op Hardening & Split-Screen UI Integration

> **Handover / Pull Request Package for `disney_infinity_multiplayer`**  
> **Authors**: Calvin & AI Pair Programmer (Google DeepMind Antigravity / Anthropic Claude)  
> **Target**: Disney Infinity 3.0: Gold Edition (PC / Steam)  
> **Base Project**: [disney_infinity_multiplayer](https://github.com/...) / CrabeLoader method  
> **License**: MIT  

---

## 📌 Executive Summary

This handover package builds directly upon the breakthrough work achieved in this repository (native drop-in via `0x69B020` and avatar materialization). 

While the initial proxy proof-of-concept successfully spawned Player 2 with an independent camera and controller, several critical roadblocks remained for gameplay:
1. **Cross-player despawn / P1 ghosting**: Changing Player 2's character despawned Player 1 or caused Player 2 to become an unmaterialized ghost.
2. **Crash on drop-in**: Pressing `START` / `+` on Controller 2 crashed intermittently due to a thread race condition between the Win32 worker thread and the DirectX render loop.
3. **Fragile heap scan**: Finding the `gameLoop` pointer took up to 500ms via heuristic memory scanning.
4. **UI spillover & lack of split-screen menus**: In-game menus (Character Selection Grid, Loadout, Tabs, Character Inspect, Abilities/Skill Tree, and Purchase/UpSell) had no split-screen support. They rendered full-screen at 100% scale, spilling across the vertical split divider, cutting off on the right edge, or rendering at incorrect screen positions.
5. **Player 2 Menu Input**: Player 2 could not select characters in the in-game UI because `GetGamepadEnabled(1)` was hardcoded to `false` in the PC build.

**All five of these roadblocks are now solved.** Player 1 and Player 2 can now drop in reliably, select and change characters independently through the native in-game menus, inspect abilities and cards, and play simultaneously with full visual isolation.

---

## 🛠️ Key Improvements & Technical Breakdown

### 1. Engine & Proxy Layer (`mod/src/coop.c` -> `coop_bink2w32.dll`)

* **Deterministic Static `gameLoop` Pointer**:
  * Replaced the asynchronous 500ms heap scan with a zero-cost, deterministic static dereference: `[base + 0x1E5F484] + 0x10`. Instant discovery (0ms), zero false positives.
* **Synchronous Main-Thread Drop-In Queue (`g_dropin_pending`)**:
  * Fixed the intermittent crash when pressing `START` on Controller 2. The drop-in request is now queued via a flag and executed synchronously on the engine's main render loop thread (`on_e01890`), eliminating the thread race condition.
* **Cross-Player Isolation (`FUN_00b73060` Hook)**:
  * In the PC build, `FUN_00b73060` was hardcoded to despawn Player 0 whenever a character switch was executed.
  * Our hook intercepts calls and maps Player 2 actions to virtual pad slot 1 (`pA`) while leaving Player 0's slot 0 (`pB`) strictly untouched. This permanently eliminates Player 1 despawns and Player 2 ghosting.
* **Lua Hook Integrations**:
  * Added clean trampolines for `GetCurrentCharacter` (`0x77FF90`), `SetCurrentCharacter` (`0x7406E0`), `ActivateChanges` (`0x783D20`), and `RemovePlayer` (`0x73EC80`) to ensure game Lua scripts reflect the real character SKU of Player 2.
* **Scene Transition & Reset Guard**:
  * Detects world unloads and map changes, resetting co-op state safely to prevent crashes during level loads.

---

### 2. Presentation UI Layer (`mod/assets/presentation/`)

In the stock PC release, the UI layout engine (`Container`) was never configured for vertical split-screen character selection. We implemented full split-screen scaling, viewport positioning, and controller routing across 9 core Lua presentation files:

| File | Changes Made |
|---|---|
| **`container.lua`** | Configured `ContainerData` vertical split definitions for all Virtual Reader screens (`VirtualReaderPC_Loadout`, `VirtualReaderPC_Tabs`, `VirtualReaderPC_GridCharacter`, `VirtualReaderPC_CharacterInspect`, `VirtualReaderPC_CoreAbilities`, `UpSellPC`). Maps viewports with exact subpixel coordinates (`targetX0 = 0.025`, `targetX1 = 0.025`, `splitY = 0.335`) to prevent UI spillover. |
| **`virtualreaderpc_gridcharacter.lua`** | Added dynamic column sizing: switches from 8 columns in single player to a compact **4-column (3x4) grid** when `UI_IsGamePlayVerticalSplit()` is active. Bypasses the PC build's `GetGamepadEnabled(1) == false` restriction so Player 2's controller can browse and select characters. |
| **`virtualreaderpc_gridbase.lua`** | Added split-screen scale (`0.5, 0.5`) and position coordination with the Container system. |
| **`virtualreaderpc_loadout.lua`** | Implemented split-screen positioning for the Loadout pedestal menu (`targetX = 0.25` for P1, `targetX = 0.75` for P2). |
| **`virtualreaderpc_tabs.lua`** | Centered and scaled the top category tab navigation bar for both viewports. |
| **`virtualreaderpc_characterinspect.lua`** | Added `0.5` scale and viewport-relative positioning for the Character Inspect card (Finn 3D model, stats, and Select/Unlock prompts), centering it below the Pause Menu. |
| **`virtualreaderpc_coreabilities.lua`** | Implemented missing `MovieLoaded` method with `0.5` scaling and viewport positioning for the Abilities / Skill Tree screen when pressing `X` on Character Inspect. |
| **`upsellpc.lua`** | Added split-screen scaling and positioning for the Character Purchase modal. |
| **`virtualreaderpc.lua`** | Cleaned base `VirtualReaderPC:MovieLoaded()` to avoid duplicate repositioning calls on derived subclasses. |

---

## 📦 File Manifest in this Package

```text
mod/
├── coop_bink2w32.dll              # Pre-compiled proxy DLL with all hooks and fixes
├── coop_bink2w32.pdb              # Debug symbols
├── coop_p2.txt                    # Initial character SKU for Player 2 (default: 0xf4308 Anakin)
├── CHARACTERS_SKU.txt             # Complete SKU reference
├── INSTALL.bat                    # Updated 1-click installer (installs DLL + UI assets with backup)
├── UNINSTALL.bat                  # 1-click uninstaller (restores stock DLL + UI assets)
├── src/
│   ├── coop.c                     # Full C source code for the proxy DLL
│   └── bink2w32.def               # Export definition file
└── assets/
    └── presentation/              # Plug-and-play UI files for the game's assets folder
        ├── container.lua
        ├── upsellpc.lua
        ├── virtualreaderpc.lua
        ├── virtualreaderpc_characterinspect.lua
        ├── virtualreaderpc_coreabilities.lua
        ├── virtualreaderpc_gridbase.lua
        ├── virtualreaderpc_gridcharacter.lua
        ├── virtualreaderpc_loadout.lua
        └── virtualreaderpc_tabs.lua
```

---

## 🔧 How to Build `coop_bink2w32.dll` (Optional)

If you wish to recompile the proxy DLL from source using [Zig](https://ziglang.org/):

```bash
cd mod/src
zig cc -O2 -shared -target x86-windows-gnu -o ../coop_bink2w32.dll coop.c bink2w32.def -lkernel32 -luser32
```

---

## 🧪 In-Game Verification Checklist

All items below have been tested and verified working in live gameplay:

- [x] **Controller 2 Join**: Pressing `START` / `+` on Controller 2 joins Player 2 cleanly with split screen.
- [x] **No Thread Crash**: Multiple joins and controller connects succeed without engine crashes.
- [x] **P1 Loadout & Selection**: Player 1 can open Character Selection, Loadout, and change character.
- [x] **P2 Loadout & Selection**: Player 2 can open Character Selection, Loadout, and change character via Controller 2.
- [x] **Simultaneous Menus**: Both players can have the Character Selection or Loadout screen open simultaneously without cross-talk.
- [x] **No Ghosting / Despawn**: Player 2 character swaps materialize solidly without causing Player 1 to despawn or become translucent.
- [x] **Character Inspect Card**: Pressing `X` on a character shows the inspect card at 50% scale, centered in the player's split half.
- [x] **Abilities Screen**: Pressing `X` on the inspect card opens Abilities/Skill Tree at 50% scale, centered in the player's split half.
- [x] **Clean Back-Out**: Backing out from Abilities -> Inspect -> Selection -> Game returns cleanly without crashing.

---

## 🤝 Attribution & Credits

- Original reverse engineering, drop-in discovery, and proxy framework by **the `disney_infinity_multiplayer` team** and **CrabeLoader ([LucasLhomme](https://github.com/LucasLhomme/DisneyInfinity-SplitScreenMods))**.
- Thread-synchronization hardening, cross-player despawn isolation, and Scaleform split-screen UI integration developed in pair-programming collaboration: **Calvin & AI (Google DeepMind Antigravity / Anthropic Claude)**.
