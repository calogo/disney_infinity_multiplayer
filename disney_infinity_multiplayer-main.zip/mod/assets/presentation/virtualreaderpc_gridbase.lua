local ava = require("AvaHelpers")
local infHelpers = require("InfinityHelpers")
local ClassFactory = require("ClassFactory")
local VirtualReaderPC = require("VirtualReaderPC")
VirtualReaderPC_GridBase = ClassFactory.CreateClass("VirtualReaderPC_GridBase", VirtualReaderPC)
VirtualReaderPC_GridBase.BaseFilterData = {
  "StarWars",
  "Marvel",
  "Disney"
}
VirtualReaderPC_GridBase.delimeter = "|"
VirtualReaderPC_GridBase.VRPC_Sort = {
  VRPC_Sort_AtoZ = 0,
  VRPC_Sort_ZtoA = 1,
  VRPC_Sort_HighestCost = 2,
  VRPC_Sort_LowestCost = 3,
  VRPC_Sort_HighestLevel = 4,
  VRPC_Sort_LowestLevel = 5,
  VRPC_Sort_Franchise = 6,
  VRPC_Sort_ByVersion = 7
}

function VirtualReaderPC_GridBase:onEnter()
  VirtualReaderPC_GridBase.superClass().onEnter(self)
  self.movieLoaded = false
  self.listData = self.listData or {}
  self.itemData = {}
  self.filterData = {}
  self.staticFilterData = {}
  self.sortData = {}
  self.itemType = self.itemType or ""
  self.numRows = self.numRows or 3
  self.numColumns = self.numColumns or 7
  self.ItemGridButtonTemplateWidth = 135
  self.ItemGridButtonTemplateHeight = 135
  self.FilterGridButtonTemplateWidth = 120
  self.FilterGridButtonTemplateHeight = 120
  self.GridFilterData = VirtualReaderPC_GetFilterButtonData()
  self.SortGridButtonTemplateWidth = 175
  self.SortGridButtonTemplateHeight = 35
  self.currentIndex = 1
  self.startId = self.startId or 1
  self.selectedId = self.selectedId or 1
  self.selectedIndex = tonumber(self.selectedId)
  self.currentPage = 0
  self.numPages = 0
  self.bIsFilterPanelOpen = false
  self.bIsSortPanelOpen = false
  self.bIsMainGridInactive = false
  self.bIsGridDisabledForOnboard = self:IsOnboardTutorialActive()
  self.staticFilterStrings = self.staticFilterStrings or {}
  self.staticSortStrings = self.staticSortStrings or {}
  self.currentSortIndex = VirtualReaderPC_GetCurrentSortMethod(self.itemType)
  self.filterBarText = ""
  self.IsTypingFilter = false
  self.bSelectingFilterCategories = false
  self.bWasSelectingCoins = false
  self.curMaxCoins = 0
  self.coinIndex = 1
  self.bMovingToGrid = false
  if self.bSelectingGridItem == nil then
    self.bSelectingGridItem = true
  end
  if self.useMovementTable == nil or self.movementTable == nil or 1 > #self.movementTable then
    self.useMovementTable = false
    self.movementTable = nil
  end
  self:SetActionMap("GN_LST_SELECT,GN_LST_CANCEL,GRD_UP,GRD_DOWN,GRD_LEFT,GRD_RIGHT,RIGHT,LEFT,UP,DOWN,GN_LST_WEST,GN_LST_NORTH,GN_LST_PAGE_UP,GN_LST_PAGE_DOWN,LT,RT,START")
  self.currentBaseFilterIndex = 1
  local currentCharacter = VirtualReaderPC_GetCurrentCharacter(self.InstanceData.playerNum)
  if currentCharacter ~= nil and currentCharacter.Name ~= nil and currentCharacter.Name ~= "" then
    local currentPlaySetBrand = VirtualReaderPC_GetBrandFromCurrentPlaySet()
    if currentPlaySetBrand ~= nil and currentPlaySetBrand ~= "" then
      self.currentBaseFilterIndex = self:GetBaseFilterIndexFropmString(currentPlaySetBrand)
    else
      local characterBrand = VirtualReaderPC_GetBrandFromName(currentCharacter.Name)
      if characterBrand ~= nil and characterBrand ~= "" then
        self.currentBaseFilterIndex = self:GetBaseFilterIndexFropmString(characterBrand)
      end
    end
  end
  local startingBrand = self.BaseFilterData[self.currentBaseFilterIndex]
  self:SetData(startingBrand, self.currentSortIndex)
  self:SetStaticFilterData()
  self:SetSortList()
  self.filterButtonTextArray = {}
end

function VirtualReaderPC_GridBase:MovieLoaded()
  VirtualReaderPC_GridBase.superClass().MovieLoaded(self)
  self.movieLoaded = true
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = (pNum == 1) and 0.75 or 0.25
    local targetY = 0.58
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen and containerScreen.SetPosition then
        containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY)
      end
    end
  end
  self:CallFlashFunction("_root.SetCurrentPage", self.currentPage + 1)
  self:CallFlashFunction("_root.SetMaxPage", self.numPages)
  if self.itemData ~= nil then
    self:CallFlashFunction("_root.ShowNoResultsMessage", false)
  end
  self:CallFlashFunction("_root.PressedSortButton", self.currentSortIndex)
  self:CallFlashFunction("_root.RebuildGrid", "filters")
  self:CallFlashFunction("_root.RebuildGrid", "sort")
  self:CallFlashFunction("_root.PressedBaseFilterButton", self.currentBaseFilterIndex - 1)
end

function VirtualReaderPC_GridBase:GetButtonLegend()
  if not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
    return "Btn_Legend_Select,btn_legend_vrpc_purchase_sparks,Btn_Legend_Back"
  else
    return "Btn_Legend_Select,Btn_Legend_Back"
  end
end

function VirtualReaderPC_GridBase:SetData(filter, sort)
  self.itemData = {}
  local numPerPage = self.numRows * self.numColumns
  self.itemData = VirtualReaderPC_GetItemByPage(self.itemType, numPerPage, self.InstanceData.playerNum, filter, sort)
  if self.itemData ~= nil then
    self.numPages = #self.itemData
    self:SetGridList(self.currentPage)
  else
    self.numPages = 1
    self.listData = {}
  end
  if self.movieLoaded then
    self:CallFlashFunction("_root.ShowNoResultsMessage", self.itemData == nil)
  end
end

function VirtualReaderPC_GridBase:SetGridList(pageNumber)
  if self.itemData == nil then
    return
  end
  self.listData = {}
  if 0 <= pageNumber and pageNumber < self.numPages then
    local numPerPage = self.numRows * self.numColumns
    for i = 1, numPerPage do
      local info = self.itemData[pageNumber + 1][i]
      if info ~= nil then
        local id = i
        local skuId = info.SkuId
        local name = info.Name
        local text = self:GetGridButtonText(info)
        local image = self:GetGridButtonImage(info)
        local description = ""
        if info.Description ~= "" and info.Description ~= nil then
          description = "@" .. info.Description
        end
        local state = self:GetGridButtonState(info)
        local sparkCost = 0
        if info.SparkCost ~= "" and info.SparkCost ~= nil then
          sparkCost = info.SparkCost
        end
        local showExtraIcon = self:ShouldShowExtraIcon(info)
        self:AddGridButton(id, skuId, name, text, image, description, state, sparkCost, showExtraIcon)
      end
    end
  end
end

function VirtualReaderPC_GridBase:SetStaticFilterData()
  self.savedFilterData = {}
  self.staticFilterData = {}
  local filter1, filter2, filter3
  filter1, filter2, filter3 = VirtualReaderPC_GetFilterButtonStrings(self.itemType)
  self.staticFilterStrings = {
    filter1,
    filter2,
    filter3
  }
  for i = 1, #self.staticFilterStrings do
    self.staticFilterData[i] = {}
    local filterString = self.staticFilterStrings[i]
    self.staticFilterData[i] = ava.splitToTable(filterString, ",")
    self.savedFilterData[i] = {}
    for j = 1, #self.staticFilterData[i] do
      self.savedFilterData[i][j] = false
    end
  end
end

function VirtualReaderPC_GridBase:SetFilterList(idx)
  self.filterData = {}
  for i = 1, #self.staticFilterData[idx] do
    local id = "filterButton_" .. tostring(i)
    local filterString = self.staticFilterData[idx][i]
    local text = ""
    local image = self:GetFilterIconPath(filterString)
    if image == nil then
      text = self:GetGridFilterDataFromId(filterString).text
    end
    local selected = self.savedFilterData[idx][i]
    self:AddFilterButton(id, filterString, image, text, selected)
  end
end

function VirtualReaderPC_GridBase:SetSortList()
  self.sortData = {}
  for i = 1, #self.staticSortStrings do
    local id = "sortButton_" .. tostring(i)
    local sortString = self.staticSortStrings[i]
    local text = "@" + sortString
    self:AddSortButton(id, sortString, text)
  end
end

function VirtualReaderPC_GridBase:GetGridButtonText(info)
  return nil
end

function VirtualReaderPC_GridBase:GetGridButtonImage(info)
  return nil
end

function VirtualReaderPC_GridBase:GetGridButtonState(info)
  local state = "available"
  if info.IsLocked then
    state = "locked"
  end
  if info.IsDead then
    state = "dead"
  end
  return state
end

function VirtualReaderPC_GridBase:ShouldShowExtraIcon(info)
  return false
end

function VirtualReaderPC_GridBase:AddGridButton(id, skuId, name, text, image, description, state, sparkCost, showExtraIcon)
  if not self.listData then
    self.listData = {}
  end
  local t = self.listData
  t[#t + 1] = {
    id = id,
    skuId = skuId,
    name = name,
    text = text,
    image = image,
    description = description,
    selected = false,
    fromMouseClick = false,
    state = state,
    locked = state == "locked",
    sparkCost = sparkCost,
    showExtraIcon = showExtraIcon,
    effectName = id,
    widgetType = "Button",
    buttonState = "",
    buttonLegend = "Btn_Legend_Select,Btn_Legend_Back",
    get = nil,
    set = nil
  }
end

function VirtualReaderPC_GridBase:AddFilterButton(id, filterString, image, text, selected)
  if not self.filterData then
    self.filterData = {}
  end
  local t = self.filterData
  t[#t + 1] = {
    id = id,
    filterString = filterString,
    image = image,
    text = text,
    selected = selected,
    widgetType = "Button",
    buttonState = "",
    buttonLegend = "Btn_Legend_Select,Btn_Legend_Back",
    get = nil,
    set = nil
  }
end

function VirtualReaderPC_GridBase:AddSortButton(id, sortString, text)
  if not self.sortData then
    self.sortData = {}
  end
  local t = self.sortData
  t[#t + 1] = {
    id = id,
    sortString = sortString,
    image = nil,
    text = text,
    selected = false,
    widgetType = "Button",
    buttonState = "",
    buttonLegend = "Btn_Legend_Select,Btn_Legend_Back",
    get = nil,
    set = nil
  }
end

function VirtualReaderPC_GridBase:AddDataEntry(t)
  self.listData[#self.listData + 1] = t
end

function VirtualReaderPC_GridBase:Rebuild(t)
  self.selectedId = self.startId
  self.selectedIndex = tonumber(self.selectedId)
  self:CallFlashFunction("_root.Rebuild")
end

function VirtualReaderPC_GridBase:GetItems(id)
  local gridData = self:GetGridDataFromId(id)
  if #gridData == 0 then
    return nil
  end
  local list = {}
  for i = 1, #gridData do
    table.insert(list, tostring(gridData[i].id))
  end
  return list
end

function VirtualReaderPC_GridBase:GetElementClassName(id, gridId)
  if id == nil then
    return
  end
  local gridData = self:GetGridDataFromId(gridId)
  local data = gridData[tonumber(id)]
  if data == nil or data.widgetType == nil then
    return "Button"
  else
    return data.widgetType
  end
end

function VirtualReaderPC_GridBase:SelectedItemChanged(id, visibleIndex)
  self.selectedId = id
  self.selectedIndex = tonumber(self.selectedId)
  self.currentIndex = tonumber(self.selectedId)
end

function VirtualReaderPC_GridBase:SelectGridItem()
end

function VirtualReaderPC_GridBase:SelectFilter()
  Sfx_Play2D("GenericList_Cancel")
  local option = self:CallFlashFunction("_root.GetCurrentElement", self:GetCurrentGrid())
  local selected = self:GetItemData(option, "selected")
  local idArray = ava.splitToTable(option, "_")
  local index = tonumber(idArray[2])
  if selected == true then
    self:ClearFilterButtonText(self.staticFilterData[self.currentBaseFilterIndex][index], true)
  else
    self:SelectSuggestionBubble(self.staticFilterData[self.currentBaseFilterIndex][index], true)
  end
  self:CallFlashFunction("_root.RebuildElement", self:GetCurrentGrid(), option)
end

function VirtualReaderPC_GridBase:ClearFilterButton(filterToClear)
  for i = 1, #self.staticFilterData do
    for j = 1, #self.staticFilterData[i] do
      local staticString = self.staticFilterData[i][j]
      if staticString == filterToClear then
        self.savedFilterData[i][j] = false
        if i == self.currentBaseFilterIndex then
          self.filterData[j].selected = false
        end
      end
    end
  end
end

function VirtualReaderPC_GridBase:SetFilterButton(filterToSet)
  for i = 1, #self.staticFilterData do
    for j = 1, #self.staticFilterData[i] do
      local staticString = self.staticFilterData[i][j]
      if staticString == filterToSet then
        self.savedFilterData[i][j] = true
        if i == self.currentBaseFilterIndex then
          self.filterData[j].selected = true
        end
      end
    end
  end
end

function VirtualReaderPC_GridBase:SelectSort()
  Sfx_Play2D("GenericList_Cancel")
  local option = self:CallFlashFunction("_root.GetCurrentElement", self:GetCurrentGrid())
  local idArray = ava.splitToTable(option, "_")
  local index = tonumber(idArray[2])
  self.currentSortIndex = index - 1
  self:CallFlashFunction("_root.PressedSortButton", self.currentSortIndex)
  VirtualReaderPC_SetCurrentSortMethod(self.currentSortIndex, self.itemType)
  self:CloseSortPanel()
  self:UpdateItemGridForFiltersAndSorting()
end

function VirtualReaderPC_GridBase:NextPage()
  if self.bIsFilterPanelOpen == false and self.bIsSortPanelOpen == false and self.numPages > 1 then
    self:CallFlashFunction("_root.PressedNextPage")
    self.currentPage = self.currentPage + 1
    if self.currentPage >= self.numPages then
      self.currentPage = 0
    end
    self:SelectPage(self.currentPage)
    self:UnselectFilterBar()
  end
end

function VirtualReaderPC_GridBase:PreviousPage()
  if self.bIsFilterPanelOpen == false and self.bIsSortPanelOpen == false and self.numPages > 1 then
    self:CallFlashFunction("_root.PressedPreviousPage")
    self.currentPage = self.currentPage - 1
    if self.currentPage < 0 then
      self.currentPage = self.numPages - 1
    end
    self:SelectPage(self.currentPage)
    self:UnselectFilterBar()
  end
end

function VirtualReaderPC_GridBase:SelectPage(idx)
  self:SetGridList(idx)
  self:CallFlashFunction("_root.RebuildGrid", self:GetCurrentGrid())
  self:CallFlashFunction("_root.SetCurrentPage", self.currentPage + 1)
end

function VirtualReaderPC_GridBase:onKeyDown(t)
  if not self.movieLoadedAndFocused then
    return
  end
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" then
      return
    end
  end
  if not t then
    return
  end
  if self.IsTypingFilter == true then
    return
  end
  local rowNumber = self:CallFlashFunction("_root.GetCurrentRow", self:GetCurrentGrid())
  if t.action == KeyMap.GN_LST_NORTH then
    if not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
      self:IncrementSparksButton()
    end
  elseif t.action == KeyMap.LT then
    self:PreviousPage()
  elseif t.action == KeyMap.RT then
    self:NextPage()
  elseif self.bSelectingGridItem == true or self.bIsFilterPanelOpen or self.bIsSortPanelOpen then
    if t.action == KeyMap.GRD_UP then
      if rowNumber == 1 and not self.bIsFilterPanelOpen and not self.bIsSortPanelOpen then
        self:CallFlashFunction("_root.MoveToFilterButtons")
        self.bSelectingGridItem = false
        self.bSelectingFilterCategories = true
      else
        self:CallFlashFunction("_root.MoveGrid", self:GetCurrentGrid(), 0)
      end
    elseif t.action == KeyMap.GRD_DOWN then
      if not self.bMovingToGrid then
        self:CallFlashFunction("_root.MoveGrid", self:GetCurrentGrid(), 1)
      else
        self.bMovingToGrid = false
      end
    elseif t.action == KeyMap.GRD_LEFT then
      self:CallFlashFunction("_root.MoveGrid", self:GetCurrentGrid(), 2)
    elseif t.action == KeyMap.GRD_RIGHT then
      self:CallFlashFunction("_root.MoveGrid", self:GetCurrentGrid(), 3)
    elseif t.action == KeyMap.GN_LST_SELECT then
      if self.bIsFilterPanelOpen then
        self:SelectFilter()
      elseif self.bIsSortPanelOpen then
        self:SelectSort()
      end
    end
  elseif self.bSelectingFilterCategories then
    if t.action == KeyMap.UP then
      self:CallFlashFunction("_root.MoveFilter", 0)
    elseif t.action == KeyMap.DOWN then
      self:CallFlashFunction("_root.MoveFilter", 1, self.bWasSelectingCoins)
    elseif t.action == KeyMap.LEFT then
      self:CallFlashFunction("_root.MoveFilter", 2)
    elseif t.action == KeyMap.RIGHT then
      self:CallFlashFunction("_root.MoveFilter", 3)
    elseif t.action == KeyMap.GN_LST_SELECT then
      self:CallFlashFunction("_root.SelectFilterButton")
    end
  elseif t.action == KeyMap.LEFT then
    self:CallFlashFunction("_root.onSelectionLeft")
    self.coinIndex = self.coinIndex - 1
    if 1 > self.coinIndex then
      self.coinIndex = 1
    end
  elseif t.action == KeyMap.RIGHT then
    self:CallFlashFunction("_root.onSelectionRight")
    self.coinIndex = self.coinIndex + 1
    if self.coinIndex > self.curMaxCoins then
      self.coinIndex = self.curMaxCoins
    end
  elseif t.action == KeyMap.UP then
    self:CallFlashFunction("_root.MoveToFilterButtons")
    self.bSelectingGridItem = false
    self.bSelectingFilterCategories = true
    self.bWasSelectingCoins = true
    self:ClearCoinButtonToolTip(self.coinIndex - 1)
  elseif t.action == KeyMap.DOWN then
  elseif t.action == KeyMap.GN_LST_SELECT then
    if self.bIsFilterPanelOpen then
      self:SelectFilter()
    elseif self.bIsSortPanelOpen then
      self:SelectSort()
    else
      self:CallFlashFunction("_root.SelectFilterButton")
    end
  end
end

function VirtualReaderPC_GridBase:NotifyMoveToGrid()
  self.bWasSelectingCoins = false
  self.bSelectingGridItem = true
  self.bSelectingFilterCategories = false
  self.bMovingToGrid = true
end

function VirtualReaderPC_GridBase:ClearCoinButtonToolTip(idx)
end

function VirtualReaderPC_GridBase:GetNumRows(id)
  local numRows
  if id == "filters" then
    numRows = 3
  elseif id == "sort" then
    numRows = 8
  else
    numRows = self.numRows
  end
  return numRows
end

function VirtualReaderPC_GridBase:GetNumColumns(id)
  local numColumns
  if id == "filters" then
    numColumns = 3
  elseif id == "sort" then
    numColumns = 1
  else
    numColumns = self.numColumns
  end
  return numColumns
end

function VirtualReaderPC_GridBase:GetGridButtonTemplateWidth(id)
  local width
  if id == "filters" then
    width = self.FilterGridButtonTemplateWidth
  elseif id == "sort" then
    width = self.SortGridButtonTemplateWidth
  else
    width = self.ItemGridButtonTemplateWidth
  end
  return width
end

function VirtualReaderPC_GridBase:GetGridButtonTemplateHeight(id)
  local height
  if id == "filters" then
    height = self.FilterGridButtonTemplateHeight
  elseif id == "sort" then
    height = self.SortGridButtonTemplateHeight
  else
    height = self.ItemGridButtonTemplateHeight
  end
  return height
end

function VirtualReaderPC_GridBase:UseMovementTable()
  return self.useMovementTable
end

function VirtualReaderPC_GridBase:GetMovementIndex(id, dir)
  local index = -1
  if self.useMovementTable ~= nil and id <= #self.movementTable and 0 <= id then
    if dir == "up" then
      index = self.movementTable[id].up
    elseif dir == "down" then
      index = self.movementTable[id].down
    elseif dir == "left" then
      index = self.movementTable[id].left
    elseif dir == "right" then
      index = self.movementTable[id].right
    else
      index = -1
    end
  end
  return index
end

function VirtualReaderPC_GridBase:GetStartID(id)
  local gridData = self:GetGridDataFromId(id)
  if gridData == nil or #gridData == 0 then
    return nil
  end
  return self.startId
end

function VirtualReaderPC_GridBase:GetElementData(id, field)
  return self:GetItemData(id, field)
end

function VirtualReaderPC_GridBase:GetItemData(id, field)
  if id == nil then
    return
  end
  local data
  local idArray = ava.splitToTable(id, "_")
  if idArray[1] == "filterButton" then
    local index = tonumber(idArray[2])
    data = self.filterData[index]
    if field == "parentGridActive" then
      return self.bIsFilterPanelOpen == true and self.bIsGridDisabledForOnboard == false
    end
  elseif idArray[1] == "sortButton" then
    local index = tonumber(idArray[2])
    data = self.sortData[index]
    if field == "parentGridActive" then
      return self.bIsSortPanelOpen == true
    end
  else
    data = self.listData[tonumber(id)]
    if field == "parentGridActive" then
      return self.bIsFilterPanelOpen == false and self.bIsSortPanelOpen == false and self.bIsMainGridInactive == false and self.bIsPopupOpen == false
    end
  end
  if data == nil then
    return nil
  end
  if field == "value" then
    if data.get then
      return data.get(self, id)
    else
      print("WARNING:  VirtualReaderPC_GridBase:GetItemData get field on ID " .. id)
      return nil
    end
  else
    if data[field] == nil then
      print("WARNING:  VirtualReaderPC_GridBase:GetItemData is asking for " .. field .. " on ID " .. id)
    end
    return data[field]
  end
end

function VirtualReaderPC_GridBase:GetActiveGrid()
  local result = "items"
  if self.bIsFilterPanelOpen == true then
    result = "filters"
  elseif self.bIsSortPanelOpen == true then
    result = "sort"
  end
  return result
end

function VirtualReaderPC_GridBase:PressedBaseFilterButton(id)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" then
      return
    end
  end
  self:UnselectFilterBar()
  local idArray = ava.splitToTable(id, "_")
  local index = tonumber(idArray[2])
  index = index + 1
  if self.currentBaseFilterIndex ~= index then
    self.currentBaseFilterIndex = index
    self:CallFlashFunction("_root.PressedBaseFilterButton", self.currentBaseFilterIndex - 1)
    if self.bIsFilterPanelOpen == true then
      self:CloseFilterPanel()
    end
    if self.bIsSortPanelOpen == true then
      self:CloseSortPanel()
    end
    for i = #self.filterButtonTextArray, 1, -1 do
      local bFound = false
      for j = 1, #self.staticFilterData[self.currentBaseFilterIndex] do
        if self.filterButtonTextArray[i].filter == self.staticFilterData[self.currentBaseFilterIndex][j] then
          bFound = true
          break
        end
      end
      if bFound == false then
        self:ClearFilterButtonText(self.filterButtonTextArray[i].text)
      end
    end
    self:UpdateItemGridForFiltersAndSorting()
    self:CallFlashFunction("_root.AddFilterTextButtons", false)
  end
end

function VirtualReaderPC_GridBase:CloseFilterPanel(returningToGrid)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" and onboardState ~= "ToyboxCharacterSearch" then
      return
    end
  end
  returningToGrid = returningToGrid or returningToGrid == nil
  self.bIsFilterPanelOpen = false
  self:CallFlashFunction("_root.CloseFilterPanel")
  self:CallFlashFunction("_root.RebuildGrid", "filters")
  if returningToGrid and not self.bIsMainGridInactive then
    self:CallFlashFunction("_root.RebuildGrid", "items")
  end
end

function VirtualReaderPC_GridBase:PressedFilterPanelButton(id)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" and onboardState ~= "ToyboxCharacterBrandFilters" then
      return
    end
  end
  if self.bIsFilterPanelOpen == false then
    self.bIsFilterPanelOpen = true
    if self.bIsSortPanelOpen == true then
      self:CloseSortPanel()
    end
    self:SetFilterList(self.currentBaseFilterIndex)
    self:CallFlashFunction("_root.RebuildGrid", "filters")
    self:CallFlashFunction("_root.RebuildGrid", "items")
    self:CallFlashFunction("_root.DeactivateGrid", "items")
    self:CallFlashFunction("_root.OpenFilterPanel")
    self:UnselectFilterBar()
  elseif self.bIsFilterPanelOpen == true then
    self:CloseFilterPanel()
  end
end

function VirtualReaderPC_GridBase:PressedSortButton(id)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" then
      return
    end
  end
  if self.bIsSortPanelOpen == false then
    self.bIsSortPanelOpen = true
    if self.bIsFilterPanelOpen == true then
      self:CloseFilterPanel()
    end
    self:CallFlashFunction("_root.RebuildGrid", "sort")
    self:CallFlashFunction("_root.RebuildGrid", "items")
    self:CallFlashFunction("_root.DeactivateGrid", "items")
    self:CallFlashFunction("_root.OpenSortPanel")
    self:UnselectFilterBar()
  elseif self.bIsSortPanelOpen == true then
    self:CloseSortPanel()
  end
end

function VirtualReaderPC_GridBase:CloseSortPanel(returningToGrid)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxCharacterSelection" then
      return
    end
  end
  returningToGrid = returningToGrid or returningToGrid == nil
  self.bIsSortPanelOpen = false
  self:CallFlashFunction("_root.CloseSortPanel")
  self:CallFlashFunction("_root.RebuildGrid", "sort")
  if returningToGrid and not self.bIsMainGridInactive then
    self:CallFlashFunction("_root.RebuildGrid", "items")
  end
end

function VirtualReaderPC_GridBase:UpdateItemGridForFiltersAndSorting()
  local filter = self:GetCurrentFilterString()
  self.currentPage = 0
  self:SetData(filter, self.currentSortIndex)
  self:CallFlashFunction("_root.RebuildGrid", "items")
  self:CallFlashFunction("_root.DeactivateGrid", "items")
  self:CallFlashFunction("_root.SetCurrentPage", self.currentPage + 1)
  self:CallFlashFunction("_root.SetMaxPage", self.numPages)
end

function VirtualReaderPC_GridBase:GetCurrentFilterString()
  local filter = self:GetBaseFilter()
  for i = 1, #self.filterButtonTextArray do
    filter = filter .. self.delimeter .. self.filterButtonTextArray[i].filter
  end
  return filter
end

function VirtualReaderPC_GridBase:GetBaseFilter()
  return self.BaseFilterData[self.currentBaseFilterIndex]
end

function VirtualReaderPC_GridBase:GetBaseFilterIndexFropmString(filterString)
  local index = 1
  for i = 1, #self.BaseFilterData do
    if filterString == self.BaseFilterData[i] then
      index = i
      break
    end
  end
  return index
end

function VirtualReaderPC_GridBase:GetCurrentGrid()
  if self.bIsFilterPanelOpen == true then
    return "filters"
  elseif self.bIsSortPanelOpen == true then
    return "sort"
  else
    return "items"
  end
end

function VirtualReaderPC_GridBase:GetGridDataFromId(id)
  local gridData
  if id == "filters" then
    gridData = self.filterData
  elseif id == "sort" then
    gridData = self.sortData
  else
    gridData = self.listData
  end
  return gridData
end

function VirtualReaderPC_GridBase:OnTabChanged(option)
  self:ExitScreen()
  VirtualReaderPC_GridBase.superClass().OnTabChanged(self, option)
end

function VirtualReaderPC_GridBase:GetFilterIconPath(name)
  local icon = self:GetGridFilterDataFromId(name).icon
  if icon == nil or icon == "" then
    return nil
  end
  return "ui/icons/" .. infHelpers:MangleIconName(icon)
end

function VirtualReaderPC_GridBase:GetFilterBarData(id, field)
  if field == "input" then
    return self.filterBarText
  elseif field == "status" then
    return 0
  elseif field == "callback" then
    return "FilterBarCallback"
  elseif field == "needsInput" then
    return true
  end
end

function VirtualReaderPC_GridBase:SelectFilterBar(id)
  self:SetNeedsKeyboardInput(true)
  self.IsTypingFilter = true
end

function VirtualReaderPC_GridBase:UnselectFilterBar()
  if self.IsTypingFilter then
    self:SetNeedsKeyboardInput(false)
    self.IsTypingFilter = false
    self:CallFlashFunction("_root.DestroySearchSuggestionBubbles")
  end
end

function VirtualReaderPC_GridBase:FilterTextEntered(text)
  if text ~= "" then
    local searchBubbles = {}
    self.searchSuggestions = nil
    self.searchSuggestions = VirtualReaderPC_GetSearchSuggestion(text, self.itemType, self:GetBaseFilter())
    if self.searchSuggestions ~= nil then
      for i = 1, #self.searchSuggestions do
        searchBubbles[#searchBubbles + 1] = self.searchSuggestions[i].text
      end
      self:CallFlashFunction("_root.CreateSearchSuggestionBubbles", searchBubbles)
    else
      self:CallFlashFunction("_root.DestroySearchSuggestionBubbles")
    end
  else
    self:CallFlashFunction("_root.DestroySearchSuggestionBubbles")
    self.filterBarText = ""
  end
end

function VirtualReaderPC_GridBase:SelectSuggestionBubble(suggestionText, bIsFilterGridButton)
  bIsFilterGridButton = bIsFilterGridButton or false
  local filter = ""
  if bIsFilterGridButton then
    filter = suggestionText
    self:SetFilterButton(suggestionText)
    suggestionText = self:GetGridFilterDataFromId(suggestionText).text
  else
    local data = self:GetGridFilterDataFromText(suggestionText)
    if data ~= nil then
      self:SetFilterButton(data.categoryId)
    end
    filter = self:GetSuggestionFilterDataFromText(suggestionText).filter
  end
  for i = #self.filterButtonTextArray, 1, -1 do
    if self.filterButtonTextArray[i].text == suggestionText then
      self:ClearFilterButtonText(suggestionText)
    end
  end
  self.filterButtonTextArray[#self.filterButtonTextArray + 1] = {text = suggestionText, filter = filter}
  self.filterBarText = ""
  self:UpdateItemGridForFiltersAndSorting()
  self:CallFlashFunction("_root.ClearFilterBarText")
  self:UnselectFilterBar()
  self:CallFlashFunction("_root.AddFilterTextButtons", false)
end

function VirtualReaderPC_GridBase:GetFilterButtonText()
  local filter = "@" + self:GetBaseFilter()
  for i = 1, #self.filterButtonTextArray do
    filter = filter .. self.delimeter .. self.filterButtonTextArray[i].text
  end
  return filter
end

function VirtualReaderPC_GridBase:PressedFilterBarButton(id)
  if self.bIsFilterPanelOpen == true then
    self:CloseFilterPanel()
  end
  if self.bIsSortPanelOpen == true then
    self:CloseSortPanel()
  end
  self:ClearFilterButtonText(id, false)
end

function VirtualReaderPC_GridBase:ClearFilterButtonText(id, bIsFilterGridButton)
  bIsFilterGridButton = bIsFilterGridButton or false
  if bIsFilterGridButton then
    self:ClearFilterButton(id)
    id = self:GetGridFilterDataFromId(id).text
  else
    local data = self:GetGridFilterDataFromText(id)
    if data ~= nil then
      self:ClearFilterButton(data.categoryId)
    end
  end
  for i = 1, #self.filterButtonTextArray do
    if self.filterButtonTextArray[i].text == id then
      table.remove(self.filterButtonTextArray, i)
      self:CallFlashFunction("_root.RemoveFilterTextButton", i)
      self:CallFlashFunction("_root.RefreshFilterTextButtons", i)
      self:UpdateItemGridForFiltersAndSorting()
      return
    end
  end
end

function VirtualReaderPC_GridBase:ForceShowNoResults()
  self.numPages = 1
  self.listData = {}
  self.currentPage = 0
  self:CallFlashFunction("_root.RebuildGrid", "items")
  self:CallFlashFunction("_root.DeactivateGrid", "items")
  self:CallFlashFunction("_root.SetCurrentPage", self.currentPage + 1)
  self:CallFlashFunction("_root.SetMaxPage", self.numPages)
  self:CallFlashFunction("_root.ShowNoResultsMessage", true)
end

function VirtualReaderPC_GridBase:FilterBarCallback(keyboardInput)
end

function VirtualReaderPC_GridBase:ReturnFromExclusiveOverlayScreen()
  self.bIsMainGridInactive = false
  VirtualReaderPC_GridBase.superClass().ReturnFromExclusiveOverlayScreen(self)
end

function VirtualReaderPC_GridBase:GoToUpSellPC(itemName)
  VirtualReaderPC_GridBase.superClass().GoToUpSellPC(self, itemName)
  self.bIsMainGridInactive = true
  self:CallFlashFunction("_root.DeactivateScreen")
end

function VirtualReaderPC_GridBase:GoToCharacterInspect(characterName)
  VirtualReaderPC_GridBase.superClass().GoToCharacterInspect(self, characterName)
  self.bIsMainGridInactive = true
  self:CallFlashFunction("_root.DeactivateScreen")
end

function VirtualReaderPC_GridBase:RefreshScreen()
  self:RefreshSparks()
end

function VirtualReaderPC_GridBase:RefreshItemGrid()
  local filter = self:GetCurrentFilterString()
  self:SetData(filter, self.currentSortIndex)
  self:CallFlashFunction("_root.RebuildGrid", "items")
end

function VirtualReaderPC_GridBase:GetGridFilterDataFromId(id)
  local result
  for i = 1, #self.GridFilterData do
    if self.GridFilterData[i].categoryId == id then
      result = self.GridFilterData[i]
      break
    end
  end
  return result
end

function VirtualReaderPC_GridBase:GetGridFilterDataFromText(text)
  local result
  for i = 1, #self.GridFilterData do
    if self.GridFilterData[i].text == text then
      result = self.GridFilterData[i]
      break
    end
  end
  return result
end

function VirtualReaderPC_GridBase:GetSuggestionFilterDataFromText(text)
  local result
  if self.searchSuggestions ~= nil then
    for i = 1, #self.searchSuggestions do
      if self.searchSuggestions[i].text == text then
        result = self.searchSuggestions[i]
        break
      end
    end
  end
  return result
end

function VirtualReaderPC_GridBase:ShowConfirmationPopup(title, body)
  VirtualReaderPC_GridBase.superClass().ShowConfirmationPopup(self, title, body)
  self:CallFlashFunction("_root.RebuildGrid", "items")
end

function VirtualReaderPC_GridBase:PopupConfirm()
  VirtualReaderPC_GridBase.superClass().PopupConfirm(self)
  self:CallFlashFunction("_root.RebuildGrid", "items")
end

function VirtualReaderPC_GridBase:PopupClosed()
  VirtualReaderPC_GridBase.superClass().PopupClosed(self)
  self:CallFlashFunction("_root.RebuildGrid", "items")
end

return VirtualReaderPC_GridBase
