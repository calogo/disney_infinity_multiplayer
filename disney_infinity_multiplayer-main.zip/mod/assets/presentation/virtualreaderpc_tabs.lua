local ava = require("AvaHelpers")

local infHelpers = require("InfinityHelpers")

local KeyMap = require("KeyMap")

local ClassFactory = require("ClassFactory")

local Screen = require("Screen")

VirtualReaderPC_Tabs = ClassFactory.CreateClass("VirtualReaderPC_Tabs", Screen)

VirtualReaderPC_Tabs.ScreenDefinition = {

  SWF = "VirtualReader/VirtualReaderPC_Tabs",

  priority = 0,

  needsInput = false,

  alwaysDoInput = true,

  doLuaInput = true

}



function VirtualReaderPC_Tabs:onEnter()

  self.hideCount = 0

  self.numVisibleElements = 4

  self.categoryList = {}

  self.avaType = "tabs"

  self.showFullBackgroundSize = true

  self.disableTabInput = false

  VirtualReaderPC_Tabs.superClass().onEnter(self)

  if not UI_IsTOGOOfflineGame() then

    self.categoryList = {

      "@Scn_VRPC_Loadout",

      "@Scn_VRPC_Characters",

      "@Scn_VRPC_RoundCoin",

      "@Scn_VRPC_HexDisc",

      "@Scn_VRPC_WebStore"

    }

  else

    self.categoryList = {

      "@Scn_VRPC_Loadout",

      "@Scn_VRPC_Characters",

      "@Scn_VRPC_RoundCoin",

      "@Scn_VRPC_HexDisc"

    }

  end

  LogUIScreenView("VirtualReaderPC_Tabs", self.InstanceData.playerNum)

end



function VirtualReaderPC_Tabs:GetSubHeaderClasses()

  return "Category"

end



function VirtualReaderPC_Tabs:GetSubHeaderData(id, str)

  local index = tonumber(id)

  local text

  if str == "text" then

    local name = self.listData[self.selectedIndex].text

    text = name

  elseif str == "value" then

    text = self.totalBonus .. "%"

  elseif str == "color" then

    text = false

  else

    assert(false, "Unknown identifier: " .. str)

  end

  return text

end



function VirtualReaderPC_Tabs:GetCategoryList()

  return self.categoryList

end



function VirtualReaderPC_Tabs:MovieLoaded()
  self.movieLoadedAndFocused = true
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = (pNum == 1) and 0.75 or 0.25
    local targetY = 0.36
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen and containerScreen.SetPosition then
        containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY)
      end
    end
  end
end



function VirtualReaderPC_Tabs:GetInitialCategoryLabel()

  return "@" .. self.headerLabel

end



function VirtualReaderPC_Tabs:reloadScreen(newPage)

  self.currentPage = tonumber(newPage)

  self.selectedIndex = 1

  self:SetData({

    PlayerID = self.playerID

  })

  self:CallFlashFunction("_root.RefreshSubHeaders")

  self:CallFlashFunction("_root.Rebuild")

end



function VirtualReaderPC_Tabs:HideVirtualReaderTabs()

  self.hideCount = self.hideCount + 1

  self:CallFlashFunction("_root.HideFast")

end



function VirtualReaderPC_Tabs:ShowVirtualReaderTabs()

  self.hideCount = self.hideCount - 1

  if self.hideCount <= 0 then

    if self.hideCount < 0 then

      self.hideCount = 0

    end

    self:CallFlashFunction("_root.ShowFast")

  end

end



function VirtualReaderPC_Tabs:SetData(t)

  if t ~= nil then

    self.DataTable = t

    self.playerID = tonumber(self.DataTable.PlayerID)

    self.headerLabel = self.categoryList[1]

  end

end



function VirtualReaderPC_Tabs:onMouseDown(t)

  if not self.movieLoadedAndFocused then

    return

  end

  if self.disableTabInput == true or self.hideCount > 0 then

    return

  end

  if not t then

    return

  end

  self.mouseDown = true

end



function VirtualReaderPC_Tabs:onMouseUp(t)

  if not self.movieLoadedAndFocused then

    return

  end

  if not t or not self.mouseDown then

    return

  end

  self.mouseDown = false

  if self.ScreenDefinition.doLuaInput then

    local x = tonumber(t.x)

    local y = tonumber(t.y)

    if t.button == 0 then

      self:CallFlashFunction("_root.handleMouseDownPos", x, y)

    end

  end

end



function VirtualReaderPC_Tabs:SetCategoryTab(index)

  self:CallFlashFunction("_root.SetCategoryTab", index)

end



function VirtualReaderPC_Tabs:OnTabChanged(option)

  local handle = UI.GetHandleFromName("VirtualReaderPC_Loadout", self.InstanceData.playerNum)

  if handle ~= UI.INVALID_UI_HANDLE then

    self:CloseCurrentVirtualReaderScreen()

    self:CallScreenFunctionByScreenName("VirtualReaderPC_Loadout", self.InstanceData.playerNum, "OnTabChanged", option)

  end

end



function VirtualReaderPC_Tabs:CloseCurrentVirtualReaderScreen()

  local currentVRHandle = UI.INVALID_UI_HANDLE

  local currentScreenName = ""

  currentVRHandle = UI.GetHandleFromName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum)

  if currentVRHandle ~= UI.INVALID_UI_HANDLE then

    currentScreenName = "VirtualReaderPC_GridCharacter"

  else

    currentVRHandle = UI.GetHandleFromName("VirtualReaderPC_GridHexCoin", self.InstanceData.playerNum)

    if currentVRHandle ~= UI.INVALID_UI_HANDLE then

      currentScreenName = "VirtualReaderPC_GridHexCoin"

    else

      currentVRHandle = UI.GetHandleFromName("VirtualReaderPC_GridRoundCoin", self.InstanceData.playerNum)

      if currentVRHandle ~= UI.INVALID_UI_HANDLE then

        currentScreenName = "VirtualReaderPC_GridRoundCoin"

      else

        currentVRHandle = UI.GetHandleFromName("VirtualReaderPC_Webstore", self.InstanceData.playerNum)

        if currentVRHandle ~= UI.INVALID_UI_HANDLE then

          currentScreenName = "VirtualReaderPC_Webstore"

        end

      end

    end

  end

  if currentScreenName ~= "" then

    self:CallScreenFunctionByScreenName(currentScreenName, self.InstanceData.playerNum, "ExitScreen")

  end

end



function VirtualReaderPC_Tabs:CloseScreen()

  self.DataTable.selection = "cancel"

  self:RequestExit()

end



function VirtualReaderPC_Tabs:onExit()

  LogUIScreenViewStepTime("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "stop")

  VirtualReaderPC_Tabs.superClass().onExit(self)

end



function VirtualReaderPC_Tabs:onKeyDown(t)

  if not self.movieLoadedAndFocused then

    return

  end

  if self.hideCount > 0 then

    return

  end

  if t.action == KeyMap.GN_LST_PAGE_UP then

    self:CallFlashFunction("_root.PreviousTab")

  elseif t.action == KeyMap.GN_LST_PAGE_DOWN then

    self:CallFlashFunction("_root.NextTab")

  else

    VirtualReaderPC_Tabs.superClass().onKeyDown(self, t)

  end

end



function VirtualReaderPC_Tabs:IsOnboardTutorialActive()

  return UI_IsOnboardTutorialActive() and System_InFrontEndOld()

end



function VirtualReaderPC_Tabs:GetOnboardTutorialStateString()

  return UI_GetOnboardTutorialStateString()

end



function VirtualReaderPC_Tabs:DisableTabInput(bDisable)

  self.disableTabInput = bDisable

end



return VirtualReaderPC_Tabs

