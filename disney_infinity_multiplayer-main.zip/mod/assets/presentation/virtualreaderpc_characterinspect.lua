local ava = require("AvaHelpers")
local infHelpers = require("InfinityHelpers")
local ClassFactory = require("ClassFactory")
local VirtualReaderPC = require("VirtualReaderPC")
VirtualReaderPC_CharacterInspect = ClassFactory.CreateClass("VirtualReaderPC_CharacterInspect", VirtualReaderPC)
VirtualReaderPC_CharacterInspect.ScreenDefinition = {
  SWF = "VirtualReader/VirtualReaderPC_CharacterInspect",
  priority = 6,
  doLuaInput = true
}

function VirtualReaderPC_CharacterInspect:init()
  VirtualReaderPC_CharacterInspect.superClass().init(self)
end

function VirtualReaderPC_CharacterInspect:MovieLoaded()
  VirtualReaderPC_CharacterInspect.superClass().MovieLoaded(self)
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = 0.025
    local targetY = 0.335
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen then
        local entry = containerScreen.ContainerData and containerScreen.ContainerData.children and containerScreen.ContainerData.children[self.InstanceData.luaName]
        if entry and containerScreen.AdjustForViewportChange then
          containerScreen:AdjustForViewportChange(self.InstanceData.luaName, entry, pNum)
        elseif containerScreen.SetPosition then
          containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY, pNum)
        end
      end
    end
  end
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC_CharacterInspect:onEnter()
  VirtualReaderPC_CharacterInspect.superClass().onEnter(self)
  self.ShowingCostume = false
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "HideVirtualReaderTabs")
  end
  self:AppendActionMap("GN_LST_WEST,GN_LST_NORTH,GN_LST_RT")
end

function VirtualReaderPC_CharacterInspect:onExit()
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "ShowVirtualReaderTabs")
  end
  if self.screenCallbackName ~= nil then
    local callbackHandle = UI.GetHandleFromName(self.screenCallbackName, self.InstanceData.playerNum)
    if callbackHandle ~= UI.INVALID_UI_HANDLE then
      self:CallScreenFunctionByScreenName(self.screenCallbackName, self.InstanceData.playerNum, "ReturnFromExclusiveOverlayScreen")
    end
  end
  VirtualReaderPC_CharacterInspect.superClass().onExit(self)
end

function VirtualReaderPC_CharacterInspect:GetButtonLegend()
  local buttonLegend
  if self.characterInfo == nil or self.characterInfo.IsLocked then
    if self.characterInfo.IsTrialPlayable then
      if not UI_IsPlalaGame() then
        buttonLegend = "Btn_Legend_VRPC_Try,Btn_Legend_VRPC_Unlock,Btn_Legend_VRPC_Abilities"
      else
        buttonLegend = "Btn_Legend_VRPC_Try,Btn_Legend_VRPC_Abilities"
      end
    elseif not UI_IsPlalaGame() then
      buttonLegend = "Btn_Legend_VRPC_Unlock,Btn_Legend_VRPC_Abilities"
    else
      buttonLegend = "Btn_Legend_VRPC_Abilities"
    end
  else
    buttonLegend = "btn_legend_vrpc_select,Btn_Legend_VRPC_Abilities"
  end
  if not UI_IsTOGOOfflineGame() then
    buttonLegend = buttonLegend .. ",Btn_Legend_VRPC_Special_Trailer"
  end
  buttonLegend = buttonLegend .. ",Btn_Legend_Back"
  return buttonLegend
end

function VirtualReaderPC_CharacterInspect:GoToSkillTree()
  if self.characterInfo == nil or self.characterInfo.IsLocked or self.characterInfo.IsTrial then
    self:AddCoreAbilitiesScreen()
    UI_SetOnboardTutorialState("CharacterAbilities")
  else
    self:AddCoreAbilitiesScreen()
  end
end

function VirtualReaderPC_CharacterInspect:AddCoreAbilitiesScreen()
  local abilitiesHandle = self:AddScreen({
    screenName = "VirtualReaderPC_CoreAbilities",
    playerNum = self.InstanceData.playerNum
  })
  if abilitiesHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_CoreAbilities", self.InstanceData.playerNum, "SetCharacterInfo", self.characterInfo.Name)
    self:CallFlashFunction("_root.DeactivateScreen")
  end
end

function VirtualReaderPC_CharacterInspect:GetItemData(id, field)
  if id == nil then
    return nil
  end
  if field == "image" and id == "CostumeCoin" then
    local costumeCoinPath = "ui/icons/"
    if self.characterInfo ~= nil then
      costumeCoinPath = costumeCoinPath .. self.characterInfo.Costume
    else
      costumeCoinPath = costumeCoinPath .. "IGP_COIN_GLORYDAYS"
    end
    return costumeCoinPath
  end
end

function VirtualReaderPC_CharacterInspect:ToggleCostume(id)
  if VirtualReaderPC_IsItemLocked(self.characterInfo.Costume, self.InstanceData.playerNum) then
    self.costumeInfo = VirtualReaderPC_GetItemByName(self.characterInfo.Costume, self.InstanceData.playerNum)
    local name = self.costumeInfo.Name
    local sparkCost = self.costumeInfo.SparkCost
    self:ShowSparksPurchasePopup(name, sparkCost)
  else
    self.ShowingCostume = not self.ShowingCostume
    self:CallFlashFunction("_root.SetCharacterImage", self.ShowingCostume)
  end
end

function VirtualReaderPC_CharacterInspect:PopupConfirm()
  if self.popupPurchasingItem == true then
    UI_IncrementSparks(-self.popupSparkCost)
    Lock_SetAvailable(self.costumeInfo.Name, self.InstanceData.playerNum)
    self.ShowingCostume = true
    self:CallFlashFunction("_root.SetCharacterImage", self.ShowingCostume)
    self:RefreshSparks()
    self:RefreshCostumeButton()
  else
    self:GoToUpSellPC(self.defaultSparkUpSell)
  end
  VirtualReaderPC_CharacterInspect.superClass().PopupConfirm(self)
end

function VirtualReaderPC_CharacterInspect:GoToUpSellPC(itemName)
  VirtualReaderPC_CharacterInspect.superClass().GoToUpSellPC(self, itemName)
  self:CallFlashFunction("_root.DeactivateScreen")
end

function VirtualReaderPC_CharacterInspect:SetCharacterInfo(characterName)
  self.characterInfo = VirtualReaderPC_GetItemByName(characterName, self.InstanceData.playerNum)
  self.characterInfo.Brand = "None"
  if self.characterInfo ~= nil and self.characterInfo.Name ~= nil then
    self.characterInfo.Brand = VirtualReaderPC_GetBrandFromName(self.characterInfo.Name)
  end
  self:CallFlashFunction("_root.SetCharacterInfo", self.characterInfo)
  self:RefreshCostumeButton()
end

function VirtualReaderPC_CharacterInspect:RefreshCostumeButton()
  local showCostumeButton = false
  local bCostumeLocked = false
  if self.characterInfo ~= nil then
    showCostumeButton = self.characterInfo.Costume ~= nil and self.characterInfo.Costume ~= "" and not self.characterInfo.IsLocked
    if showCostumeButton then
      bCostumeLocked = VirtualReaderPC_IsItemLocked(self.characterInfo.Costume, self.InstanceData.playerNum)
    end
  end
  self:CallFlashFunction("_root.ShowCostumeButton", showCostumeButton, bCostumeLocked)
end

function VirtualReaderPC_CharacterInspect:onKeyDown(t)
  if not self.movieLoadedAndFocused then
    return
  end
  if t.action == KeyMap.GN_LST_CANCEL or t.action == KeyMap.CANCEL then
    self:HandleCloseButton()
  elseif t.action == KeyMap.GN_LST_SELECT then
    self:SelectOrUnlockCharacter()
  elseif t.action == KeyMap.GN_LST_NORTH then
    if not UI_IsPlalaGame() and self.characterInfo.IsTrialPlayable then
      self:SelectCharacter()
    end
  elseif t.action == KeyMap.GN_LST_WEST then
    self:GoToSkillTree()
  elseif not UI_IsTOGOOfflineGame() and t.action == KeyMap.GN_LST_RT then
    self:PlayTrailer()
  end
end

function VirtualReaderPC_CharacterInspect:PlayTrailer()
  PlayBinkMovie(self.characterInfo.VideoLink, true, 0, true)
end

function VirtualReaderPC_CharacterInspect:SelectOrUnlockCharacter()
  if self.characterInfo.Name ~= nil then
    if UI_IsPlalaGame() then
      if not self.characterInfo.IsLocked or self.characterInfo.IsTrialPlayable then
        self:SelectCharacter()
      end
    elseif self.characterInfo.IsLocked then
      self:GoToUpSellPC(self.characterInfo.Name)
    else
      self:SelectCharacter()
    end
  end
end

function VirtualReaderPC_CharacterInspect:SelectCharacter()
  VirtualReaderPC_SetCurrentCharacter(self.characterInfo.SkuId)
  local GridCharacterSelectHandle = UI.GetHandleFromName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum)
  if GridCharacterSelectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(GridCharacterSelectHandle, "ExitScreen")
  end
  local TrialCharactersSelectHandle = UI.GetHandleFromName("TrialCharacters", self.InstanceData.playerNum)
  if TrialCharactersSelectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(TrialCharactersSelectHandle, "ExitScreen")
  end
  self:ExitScreen()
  self:ReturnToLoadout()
end

function VirtualReaderPC_CharacterInspect:HandleCloseButton()
  if not self.movieLoadedAndFocused then
    return
  end
  self:ExitScreen()
  local GridCharacterSelectHandle = UI.GetHandleFromName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum)
  local TrialCharactersSelectHandle = UI.GetHandleFromName("TrialCharacters", self.InstanceData.playerNum)
  if GridCharacterSelectHandle == UI.INVALID_UI_HANDLE and TrialCharactersSelectHandle == UI.INVALID_UI_HANDLE then
    self:ReturnToLoadout()
  end
end

function VirtualReaderPC_CharacterInspect:GetCharacterIconName(name)
  local nameTable = ava.splitToTable(name, "_")
  local baseName = nameTable[#nameTable]
  local lookUpName = infHelpers.CollectionViewerLookupTable[name]
  if name == "MU_Sully" then
    lookUpName = "Sully"
  end
  local largeLookUpName = ""
  if lookUpName ~= nil and lookUpName ~= "" then
    largeLookUpName = infHelpers.LargeCollectionViewerLookupTable[lookUpName]
  end
  local largeIconname = ""
  if largeLookUpName ~= nil and largeLookUpName ~= "" then
    largeIconname = "AV_" .. largeLookUpName
  elseif lookUpName ~= nil and lookUpName ~= "" then
    largeIconname = "AV_" .. lookUpName
  else
    largeIconname = "AV_" .. baseName
  end
  if largeIconname == "AV_Emmitt" or largeIconname == "AV_Grimm" or largeIconname == "AV_James" or largeIconname == "AV_Lola" then
    largeIconname = "PSX_" .. largeIconname
  end
  return largeIconname
end

function VirtualReaderPC_CharacterInspect:GetBrandFromName(name)
  return VirtualReaderPC_GetBrandFromName(name)
end

function VirtualReaderPC_CharacterInspect:SetScreenCallbackName(parentScreenName)
  self.screenCallbackName = parentScreenName
end

function VirtualReaderPC_CharacterInspect:RefreshScreen()
  self:SetCharacterInfo(self.characterInfo.Name)
  self:SetButtonLegend(self:GetButtonLegend())
  self:RefreshCostumeButton()
end

return VirtualReaderPC_CharacterInspect
