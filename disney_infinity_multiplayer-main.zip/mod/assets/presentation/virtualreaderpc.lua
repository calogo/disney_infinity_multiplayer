local ava = require("AvaHelpers")
local VirtualReaderData = require("VirtualReaderData")
local infHelpers = require("InfinityHelpers")
local KeyMap = require("KeyMap")
local ClassFactory = require("ClassFactory")
local Screen = require("Screen")
VirtualReaderPC = ClassFactory.CreateClass("VirtualReaderPC", Screen)
LastScreen = "loadout"
VirtualReaderPC.ScreenDefinition = {
  SWF = "VirtualReader/VirtualReaderPC",
  layer = "main",
  priority = 0,
  needsInput = true,
  doLuaInput = true
}
VirtualReaderPC.DataProvider = {}
VirtualReaderPC.ConfirmationPopup = {
  GetTitle = function(self)
    return self.title
  end,
  GetBody = function(self)
    return self.body
  end,
  GetList = function(self)
    return self.list
  end,
  GetTranslateBody = function(self)
    return self.doTranslateBody
  end,
  SelectOption = function(self, option)
    if option == "SharedText_Yes" then
      self.onConfirm()
    else
      self.onDeny()
    end
    self.parent:RequestExit(self.parent.confirmPopupHandle)
  end
}

function VirtualReaderPC:onEnter()
  VirtualReaderPC.superClass().onEnter(self)
  print("Virtual Reader PC: onEnter\n")
  VirtualReaderPC_ValidateCurrentCharacter()
  self.bIsPopupOpen = false
  self.defaultSparkUpSell = "Small_SP"
  self.popupPurchasingItem = false
  self.popupSparkCost = 0
  self:SetActionMap("GN_LST_SELECT,GN_LST_PAGE_UP,GN_LST_PAGE_DOWN,GN_LST_CANCEL,CANCEL,RIGHT,LEFT,UP,DOWN,DEFAULT_X,DEFAULT_Y")
  self:SetFocus(false)
  self:RefreshEntitlements()
  if self.EntitlementsPingTimerHandle == nil then
    self.EntitlementsPingTimerHandle = self:ScheduleTimer("REPEAT", 60, "EntitlementPing")
  end
end

function VirtualReaderPC:onExit()
  print("Virtual Reader PC: onExit\n")
  VirtualReaderPC.superClass().onExit(self)
  if self.EntitlementsPingTimerHandle ~= nil then
    self:RemoveTimer(self.EntitlementsPingTimerHandle)
    self.EntitlementsPingTimerHandle = nil
  end
end

function VirtualReaderPC:onRestore()
  print("Virtual Reader PC: onRestore\n")
end

function VirtualReaderPC:MovieLoaded(s)
  print("Virtual Reader PC: MovieLoaded\n")
  self:Show()
  self:SetButtonLegend(self:GetButtonLegend())
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC:GetButtonLegend()
  return "Btn_Legend_Exit"
end

function VirtualReaderPC:OnTabChanged(option)
  self.movieLoadedAndFocused = false
  if option == "loadout" then
    self:ReturnToLoadout()
    LastScreen = option
  elseif option == "characters" then
    self:AddScreen({
      screenName = "VirtualReaderPC_GridCharacter",
      playerNum = self.InstanceData.playerNum
    })
    LastScreen = option
  elseif option == "coins" then
    self:AddScreen({
      screenName = "VirtualReaderPC_GridRoundCoin",
      playerNum = self.InstanceData.playerNum
    })
    LastScreen = option
  elseif option == "hexdisks" then
    self:AddScreen({
      screenName = "VirtualReaderPC_GridHexCoin",
      playerNum = self.InstanceData.playerNum
    })
    LastScreen = option
  elseif option == "webstore" then
    if not UI_IsTOGOOfflineGame() then
      self:AddScreen({
        screenName = "VirtualReaderPC_Webstore",
        playerNum = self.InstanceData.playerNum
      })
      LastScreen = option
    elseif LastScreen == "hexdisks" then
      self:ReturnToLoadout()
      LastScreen = "loadout"
    else
      self:AddScreen({
        screenName = "VirtualReaderPC_GridHexCoin",
        playerNum = self.InstanceData.playerNum
      })
      LastScreen = "hexdisks"
    end
  else
    print("Unexpected option in TabChanged: " .. option)
    self.movieLoadedAndFocused = true
    LastScreen = ""
    return
  end
end

function VirtualReaderPC:ReturnToLoadout()
  self.movieLoadedAndFocused = false
  local loadoutHandle = UI.GetHandleFromName("VirtualReaderPC_Loadout", self.InstanceData.playerNum)
  if loadoutHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Loadout", self.InstanceData.playerNum, "onRestore")
  end
end

function VirtualReaderPC:GoToCharacterInspect(characterName)
  self.movieLoadedAndFocused = false
  local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
  local screenParams = {
    screenName = "VirtualReaderPC_CharacterInspect",
    playerNum = self.InstanceData.playerNum
  }
  if containerHandle ~= UI.INVALID_UI_HANDLE then
    screenParams.attachHandle = containerHandle
  end
  local inspectHandle = self:AddScreen(screenParams)
  if inspectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum, "SetCharacterInfo", characterName)
    self:CallScreenFunctionByScreenName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum, "SetScreenCallbackName", self.InstanceData.luaName)
  end
end

function VirtualReaderPC:GoToUpSellPC(itemName)
  self.movieLoadedAndFocused = false
  local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
  local screenParams = {
    screenName = "UpSellPC",
    playerNum = self.InstanceData.playerNum
  }
  if containerHandle ~= UI.INVALID_UI_HANDLE then
    screenParams.attachHandle = containerHandle
  end
  local upsellHandle = self:AddScreen(screenParams)
  if upsellHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("UpSellPC", self.InstanceData.playerNum, "SetItemInfo", itemName)
    self:CallScreenFunctionByScreenName("UpSellPC", self.InstanceData.playerNum, "SetScreenCallbackName", self.InstanceData.luaName)
  end
end

function VirtualReaderPC:ReturnFromExclusiveOverlayScreen()
  self:CallFlashFunction("_root.ActivateScreen")
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC:HandleCloseButton()
  self.movieLoadedAndFocused = false
  self:CallFlashFunction("_root.HandleCloseButton")
end

function VirtualReaderPC:onKeyDown(t)
  if not self.movieLoadedAndFocused then
    return
  end
  self.keyDown = true
  if t.action == KeyMap.GN_LST_CANCEL or t.action == KeyMap.CANCEL then
    self:HandleCloseButton()
  end
end

function VirtualReaderPC:onKeyUp(t)
  if self.keyDown == false then
    return
  end
  self.keyDown = false
end

function VirtualReaderPC:GetCurrentSparks()
  return UI_GetSparks()
end

function VirtualReaderPC:IsOnboardTutorialActive()
  return UI_IsOnboardTutorialActive() and System_InFrontEndOld()
end

function VirtualReaderPC:TranslateHelper(text)
  return Translator_TranslateString(text, true, self.InstanceData.playerNum)
end

function VirtualReaderPC:IncrementSparksButton(id)
  self:GoToUpSellPC(self.defaultSparkUpSell)
end

function VirtualReaderPC:RefreshSparks()
  self:CallFlashFunction("_root.RefreshSparks")
end

function VirtualReaderPC:GetIconPath(name, icon)
  local path = "ui/icons/"
  if VirtualReaderPC_IsItemPlayset(name) or VirtualReaderPC_IsItemToyBoxGame(name) then
    path = "ui/FELargeIGPs/" .. icon
  elseif VirtualReaderPC_IsItemAvatarBundle(name) then
    path = "ui/FELargeIGPs/" .. infHelpers:MangleIconName(name) .. "_Upsell"
  elseif VirtualReaderPC_IsItemAvatar(name) then
    path = "ui/virtualreadercharacters/" .. infHelpers:MangleIconName(name)
  elseif VirtualReaderPC_IsItemHexCoinBundle(name) then
    path = "ui/icons/" .. infHelpers:MangleIconName(name)
  elseif VirtualReaderPC_IsItemStarterPack(name) then
    path = "ui/FELargeIGPs/" .. name .. "_Upsell"
  elseif VirtualReaderPC_IsItemSparkPack(name) then
    path = path .. name
  elseif VirtualReaderPC_IsItemMiscLock(name) then
    path = "ui/FELargeIGPs/" .. icon
  else
    path = path .. icon
  end
  return path
end

function VirtualReaderPC:HasLargeIcon(name)
  return VirtualReaderPC_IsItemPlayset(name) or VirtualReaderPC_IsItemToyBoxGame(name) or VirtualReaderPC_IsItemStarterPack(name) or VirtualReaderPC_IsItemAvatarBundle(name) or VirtualReaderPC_IsItemMiscLock(name)
end

function VirtualReaderPC:ShowConfirmationPopup(title, body)
  self.bIsPopupOpen = true
  self.ConfirmationPopup.parent = self
  self.ConfirmationPopup.option = nil
  self.ConfirmationPopup.title = title
  self.ConfirmationPopup.body = body
  self.ConfirmationPopup.list = {
    "SharedText_Yes",
    "SharedText_No"
  }
  
  function self.ConfirmationPopup.onConfirm()
    self:PopupConfirm()
  end
  
  function self.ConfirmationPopup.onDeny()
    self:PopupClosed()
  end
  
  self.ConfirmationPopup.doTranslateBody = false
  self.confirmPopupHandle = self:AddScreen({
    screenName = "Popup",
    playerNum = self.InstanceData.playerNum,
    dataProvider = self.ConfirmationPopup
  })
  self:DisableTabs(true)
end

function VirtualReaderPC:PopupConfirm()
  self:DisableTabs(false)
  self.bIsPopupOpen = false
end

function VirtualReaderPC:PopupClosed()
  self:DisableTabs(false)
  self.bIsPopupOpen = false
end

function VirtualReaderPC:DisableTabs(bDisable)
  local tabHandle = self:AddScreen({
    screenName = "VirtualReaderPC_Tabs",
    playerNum = self.InstanceData.playerNum
  })
  if tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "DisableTabInput", bDisable)
  end
end

function VirtualReaderPC:ShowSparksPurchasePopup(name, sparkCost)
  local loc_name = ""
  if name ~= nil then
    loc_name = self:TranslateHelper(name .. "_name")
  end
  if sparkCost <= self:GetCurrentSparks() then
    self.popupPurchasingItem = true
    self.popupSparkCost = sparkCost
    local translatedPurchaseBody = self:TranslateHelper("Purchase_PurchaseItemForCost")
    if translatedPurchaseBody ~= "" then
      if UI_IsPlalaGame() then
        translatedPurchaseBody = string.format(translatedPurchaseBody, sparkCost, loc_name)
      else
        translatedPurchaseBody = string.format(translatedPurchaseBody, loc_name, sparkCost)
      end
    end
    self:ShowConfirmationPopup("Purchase_ConfirmPurchase", translatedPurchaseBody)
  elseif not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
    self.popupPurchasingItem = false
    local translatedSparkBody = self:TranslateHelper("Purchase_PurchaseSparksForItemForCost")
    if translatedSparkBody ~= "" then
      translatedSparkBody = string.format(translatedSparkBody, loc_name, sparkCost)
    end
    self:ShowConfirmationPopup("Purchase_NotEnoughSparks", translatedSparkBody)
  else
    self:ShowSparksPopupMessage()
  end
end

function VirtualReaderPC:ShowSparksPopupMessage()
  local popup = {
    title = "@Purchase_NotEnoughSparks",
    body = "@Scn_InsufficientSpark",
    list = "SharedText_Ok",
    buttonPrompts = "Btn_Legend_Select",
    onSelect = function(option)
      self:DisableTabs(false)
    end,
    hideArrow = true,
    allowCancel = false
  }
  self.popupHandle = self:AddScreen({screenName = "Popup"})
  self:CallScreen(self.popupHandle, "SetUsingTable", popup, true)
  self:DisableTabs(true)
end

function VirtualReaderPC:EntitlementPing()
  self:RefreshEntitlements()
end

function VirtualReaderPC:RefreshEntitlements()
  self.currentEntitlementTime = 0
  local success = VirtualReaderPC_GetAvatarEntitlements(self.InstanceData.playerNum)
end

return VirtualReaderPC
