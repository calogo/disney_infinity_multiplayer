local ava = require("AvaHelpers")
local infHelpers = require("InfinityHelpers")
local KeyMap = require("KeyMap")
local ClassFactory = require("ClassFactory")
local VirtualReaderPC = require("VirtualReaderPC")
VirtualReaderPC_Loadout = ClassFactory.CreateClass("VirtualReaderPC_Loadout", VirtualReaderPC)
VirtualReaderPC_Loadout.ScreenDefinition = {
  SWF = "VirtualReader/VirtualReaderPC_Loadout",
  layer = "main",
  priority = 1,
  needsInput = true
}
VirtualReaderPC_Loadout.ErrorPopup = {
  GetTitle = function(self)
    return self.title
  end,
  GetBody = function(self)
    return self.body
  end,
  GetList = function(self)
    return self.list
  end,
  SelectOption = function(self, option)
    self.onClose()
    self.parent:RequestExit(self.parent.errorPopupHandle)
  end
}
VirtualReaderPC_Loadout.CostumeRoundCoinPosition = 2

function VirtualReaderPC_Loadout:onEnter()
  LogUIScreenView("reader", self.InstanceData.playerNum)
  if not System_InFrontEndOld() then
    Pause_PauseGame(self.InstanceData.playerNum, false, false)
    VirtualReaderPC_PlaysetCheckInGame()
  else
    local handle = UI.GetFrontEndContainerHandle()
    self:CallScreen(handle, "EnterFullScreen", "OnboardTutorial")
  end
  self.tabHandle = self:AddScreen({
    screenName = "VirtualReaderPC_Tabs",
    playerNum = self.InstanceData.playerNum
  })
  self.forceAvatarChange = false
  VirtualReaderPC_Loadout.superClass().onEnter(self)
  UI_ShowCursor()
  LogUIScreenView("VirtualReaderPC_Loadout", self.InstanceData.playerNum)
  self:AppendActionMap("GN_LST_WEST,GN_LST_NORTH,DEFAULT_LT")
  self.currentCharacter = VirtualReaderPC_GetCurrentCharacter(self.InstanceData.playerNum)
  self.hitContinue = false
  self.hitRevive = false
  if self.currentCharacter ~= nil and self.currentCharacter.Costume ~= nil and self.currentCharacter.Costume ~= "" then
    self.costumeInfo = VirtualReaderPC_GetItemByName(self.currentCharacter.Costume, self.InstanceData.playerNum)
  end
  local socialHubHandle = UI.GetHandleFromName("social_hub", self.InstanceData.playerNum)
  if socialHubHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("social_hub", self.InstanceData.playerNum, "HideHub")
  end
end

function VirtualReaderPC_Loadout:onExit()
  Pause_UnPauseFromPausedScreenIfPaused(self.InstanceData.playerNum)
  SaveLoad_AutoSaveProfile(false, "", "", true, true, true)
  VirtualReaderPC_ActivateChanges(self.InstanceData.playerNum, self.forceAvatarChange)
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "RequestExit")
    self.tabHandle = UI.INVALID_UI_HANDLE
  end
  VirtualReaderPC_Loadout.superClass().onExit(self)
  UI_HideCursor()
  if System_InFrontEndOld() then
    local handle = UI.GetFrontEndContainerHandle()
    self:CallScreen(handle, "ExitFullScreen")
  end
  local socialHubHandle = UI.GetHandleFromName("social_hub", self.InstanceData.playerNum)
  if socialHubHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("social_hub", self.InstanceData.playerNum, "ShowHub")
  end
  LogUIScreenViewStepTime("VirtualReaderPC_Loadout", self.InstanceData.playerNum, "stop")
end

function VirtualReaderPC_Loadout:onRestore()
  if self:IsOnboardTutorialActive() then
    UI_ShowOnboardTutorialOverlay()
  end
  self:UpdateCharacter()
  self:UpdateHexCoins()
  self:UpdateRoundCoins()
  self:CallFlashFunction("_root.OnRestore")
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = (pNum == 1) and 0.75 or 0.25
    local targetY = 0.58
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen and containerScreen.SetPosition then
        containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY)
      end
    end
  end
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "SetCategoryTab", 0)
  end
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC_Loadout:MovieLoaded(s)
  self:Show()
  self:UpdateCharacter()
  self:UpdateHexCoins()
  self:UpdateRoundCoins()
  self:SetButtonLegend(self:GetButtonLegend())
  if self:IsOnboardTutorialActive() then
    UI_ShowOnboardTutorialOverlay()
  elseif VirtualReaderPC_ShouldShowTrialCharacters() then
    self:CallFlashFunction("_root.OnLeave")
    VirtualReaderPC_ShowTrialCharactersScreen()
  end
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = (pNum == 1) and 0.75 or 0.25
    local targetY = 0.58
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen and containerScreen.SetPosition then
        containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY)
      end
    end
  end
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC_Loadout:GetItemData(id, field)
  if id == nil then
    return nil
  end
  local iconpath = ""
  local imageName = ""
  if field ~= "image" or id == "character" then
  elseif id == "costume" then
    if self.currentCharacter then
      imageName = self.currentCharacter.Costume
    end
  elseif id == "inspect" then
  else
    local idArray = ava.splitToTable(id, "_")
    local index = tonumber(idArray[2])
    if idArray[1] == "hex" then
      if self.currentHexCoins ~= nil and index < #self.currentHexCoins then
        imageName = self.currentHexCoins[index + 1].Name
      end
    elseif idArray[1] == "round" and self.currentRoundCoins ~= nil and index < #self.currentRoundCoins then
      imageName = self.currentRoundCoins[index + 1].Name
    end
  end
  if imageName ~= nil and 1 < #imageName then
    iconpath = "ui/icons/" .. infHelpers:MangleIconName(imageName)
  end
  return iconpath
end

function VirtualReaderPC_Loadout:UpdateCharacter()
  self.costumeActive = false
  self.currentCharacter = VirtualReaderPC_GetCurrentCharacter(self.InstanceData.playerNum)
  if self.currentCharacter ~= nil then
    if self.currentCharacter.Costume ~= nil and self.currentCharacter.Costume ~= "" then
      self.costumeInfo = VirtualReaderPC_GetItemByName(self.currentCharacter.Costume, self.InstanceData.playerNum)
    end
    local currentEquippedCoins = {}
    currentEquippedCoins = VirtualReaderPC_GetCurrentRoundCoins(self.InstanceData.playerNum)
    if currentEquippedCoins ~= nil and currentEquippedCoins[self.CostumeRoundCoinPosition + 1] ~= nil then
      if self.currentCharacter.Costume ~= nil and self.currentCharacter.Costume ~= "" and self.currentCharacter.Costume == currentEquippedCoins[self.CostumeRoundCoinPosition + 1].Name then
        self.costumeActive = true
      else
        VirtualReaderPC_RemoveRoundCoin(self.CostumeRoundCoinPosition)
      end
    end
  end
  self:CallFlashFunction("_root.RefreshCharacter")
  self:RefreshCostumeButton()
end

function VirtualReaderPC_Loadout:RefreshCostumeButton()
  local showCostumeButton = false
  local bCostumeLocked = false
  if self.currentCharacter ~= nil then
    showCostumeButton = self.currentCharacter.Costume ~= nil and self.currentCharacter.Costume ~= ""
    if showCostumeButton then
      bCostumeLocked = VirtualReaderPC_IsItemLocked(self.currentCharacter.Costume, self.InstanceData.playerNum)
    end
  end
  self:CallFlashFunction("_root.ShowCostumeButton", showCostumeButton, bCostumeLocked)
end

function VirtualReaderPC_Loadout:UpdateHexCoins()
  self.currentHexCoins = VirtualReaderPC_GetCurrentHexCoins(self.InstanceData.playerNum)
  self:CallFlashFunction("_root.RefreshHexDisks")
end

function VirtualReaderPC_Loadout:UpdateRoundCoins()
  self.currentRoundCoins = VirtualReaderPC_GetCurrentRoundCoins(self.InstanceData.playerNum)
  self:CallFlashFunction("_root.RefreshRoundCoins")
end

function VirtualReaderPC_Loadout:GetCurrentCharacterImage(bIncludeCostume)
  local imageName = "ui/virtualreadercharacters/" .. infHelpers:MangleIconName("Default")
  if self.currentCharacter ~= nil then
    imageName = "ui/virtualreadercharacters/" .. infHelpers:MangleIconName(self.currentCharacter.Name)
    if self.costumeActive == true and bIncludeCostume == true then
      imageName = imageName .. "_" .. self.currentCharacter.Costume
    end
  end
  return imageName
end

function VirtualReaderPC_Loadout:GetCurrentCharacterName()
  local characterName = ""
  if self.currentCharacter ~= nil and self.currentCharacter.Name ~= nil then
    characterName = "@" .. self.currentCharacter.Name
  end
  return characterName
end

function VirtualReaderPC_Loadout:GetCurrentCharacterLevel()
  local characterLevel = ""
  if self.currentCharacter ~= nil and self.currentCharacter.Level ~= nil then
    local translatedLevelText = self:TranslateHelper("Avatar_Level")
    if translatedLevelText ~= "" then
      translatedLevelText = string.format(translatedLevelText, self.currentCharacter.Level)
      characterLevel = translatedLevelText
    end
  end
  return characterLevel
end

function VirtualReaderPC_Loadout:GetCurrentCharacterIsDead()
  local bIsDead = false
  if self.currentCharacter ~= nil and self.currentCharacter.IsDead ~= nil then
    bIsDead = self.currentCharacter.IsDead
  end
  return bIsDead
end

function VirtualReaderPC_Loadout:GetCurrentCharacterBrand()
  local characterBackground = "None"
  if self.currentCharacter ~= nil and self.currentCharacter.Name ~= nil then
    characterBackground = VirtualReaderPC_GetBrandFromName(self.currentCharacter.Name)
  end
  return characterBackground
end

function VirtualReaderPC_Loadout:GetIsDailyChallenge()
  return DailyChallenge_IsDailyChallengeActive()
end

function VirtualReaderPC_Loadout:HasCharacterInfo()
  return self.currentCharacter ~= nil
end

function VirtualReaderPC_Loadout:GetCurrentHexName(index)
  local name = ""
  if self.currentHexCoins ~= nil and 0 <= index and index < #self.currentHexCoins and self.currentHexCoins[index + 1].Name ~= nil and self.currentHexCoins[index + 1].Name ~= "" then
    name = "@" .. self.currentHexCoins[index + 1].Name .. "_name"
  end
  return name
end

function VirtualReaderPC_Loadout:GetCurrentRoundName(index)
  local name = ""
  if self.currentRoundCoins ~= nil and 0 <= index and index < #self.currentRoundCoins and self.currentRoundCoins[index + 1].Name ~= nil and self.currentRoundCoins[index + 1].Name ~= "" then
    name = "@" .. self.currentRoundCoins[index + 1].Name .. "_name"
  end
  return name
end

function VirtualReaderPC_Loadout:OnTabChanged(option)
  if option ~= "loadout" then
    self:CallFlashFunction("_root.OnLeave")
  end
  VirtualReaderPC_Loadout.superClass().OnTabChanged(self, option)
end

function VirtualReaderPC_Loadout:SelectCharacter(id)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState == "LoadoutCharacterSlot" then
      UI_SetOnboardTutorialState("CharacterSelection")
    elseif onboardState == "ToyboxCharacterSlot" then
      UI_SetOnboardTutorialState("ToyboxCharacterDescription")
    else
      return
    end
  end
  self:CallFlashFunction("_root.OnLeave")
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "SetCategoryTab", 1)
  end
  self:OnTabChanged("characters")
end

function VirtualReaderPC_Loadout:SelectHexDisk(id)
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "ToyboxLoadout" and onboardState ~= "ToyboxCoins" then
      return
    else
      UI_SetOnboardTutorialState("HexSelection")
    end
  end
  self:CallFlashFunction("_root.OnLeave")
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "SetCategoryTab", 3)
  end
  local hexHandle = self:AddScreen({
    screenName = "VirtualReaderPC_GridHexCoin",
    playerNum = self.InstanceData.playerNum
  })
  if hexHandle ~= UI.INVALID_UI_HANDLE then
    local idArray = ava.splitToTable(id, "_")
    local index = tonumber(idArray[2])
    self:CallScreenFunctionByScreenName("VirtualReaderPC_GridHexCoin", self.InstanceData.playerNum, "SelectCoinButton", index)
  end
end

function VirtualReaderPC_Loadout:SelectRoundCoin(id)
  if self:IsOnboardTutorialActive() then
    return
  end
  self:CallFlashFunction("_root.OnLeave")
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "SetCategoryTab", 2)
  end
  local roundHandle = self:AddScreen({
    screenName = "VirtualReaderPC_GridRoundCoin",
    playerNum = self.InstanceData.playerNum
  })
  if roundHandle ~= UI.INVALID_UI_HANDLE then
    local idArray = ava.splitToTable(id, "_")
    local index = tonumber(idArray[2])
    self:CallScreenFunctionByScreenName("VirtualReaderPC_GridRoundCoin", self.InstanceData.playerNum, "SelectCoinButton", index)
  end
end

function VirtualReaderPC_Loadout:SelectCharacterInspect(id)
  if self:IsOnboardTutorialActive() then
    return
  end
  self:CallFlashFunction("_root.OnLeave")
  if self.currentCharacter.Name ~= nil then
    self:GoToCharacterInspect(self.currentCharacter.Name)
  end
end

function VirtualReaderPC_Loadout:SelectCostume(id)
  if self:IsOnboardTutorialActive() then
    return
  end
  if self.currentCharacter.IsLocked then
    self:GoToUpSellPC(self.currentCharacter.Name)
  elseif VirtualReaderPC_IsItemLocked(self.currentCharacter.Costume, self.InstanceData.playerNum) then
    local name = self.costumeInfo.Name
    local sparkCost = self.costumeInfo.SparkCost
    self:ShowSparksPurchasePopup(name, sparkCost)
  else
    if self.costumeActive == true then
      self.costumeActive = false
      VirtualReaderPC_RemoveRoundCoin(self.CostumeRoundCoinPosition)
    else
      self.costumeActive = true
      VirtualReaderPC_SetCurrentRoundCoin(self.costumeInfo.SkuId, self.CostumeRoundCoinPosition)
    end
    self:CallFlashFunction("_root.RefreshCharacter")
  end
end

function VirtualReaderPC_Loadout:PopupConfirm()
  if self.popupPurchasingItem == true then
    UI_IncrementSparks(-self.popupSparkCost)
    local costumeName = self.costumeInfo.Name
    local isPSX = ava.strStartsWith(costumeName, "PSX_")
    if isPSX then
      costumeName = string.sub(costumeName, 5, #costumeName)
    end
    Lock_SetAvailable(costumeName, self.InstanceData.playerNum)
    self.costumeActive = true
    VirtualReaderPC_SetCurrentRoundCoin(self.costumeInfo.SkuId, self.CostumeRoundCoinPosition)
    self:CallFlashFunction("_root.RefreshCharacter")
    self:RefreshSparks()
    self:RefreshCostumeButton()
  else
    self:GoToUpSellPC(self.defaultSparkUpSell)
  end
  VirtualReaderPC_Loadout.superClass().PopupConfirm(self)
end

function VirtualReaderPC_Loadout:onKeyDown(t)
  if not self.movieLoadedAndFocused then
    return
  end
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState == "ToyboxLoadoutDescription" or onboardState == "ToyboxLoadout" then
      if t.action == KeyMap.GN_LST_SELECT then
        UI_AdvanceOnboardTutorialState()
        self:SetButtonLegend(self:GetButtonLegend())
      end
      return
    elseif onboardState ~= "ToyboxCharacterSlot" then
      if onboardState == "ToyboxLoadoutPlay" then
        if t.action ~= KeyMap.GN_LST_WEST then
          return
        end
      else
        return
      end
    elseif t.action == KeyMap.GN_LST_PAGE_UP or t.action == KeyMap.GN_LST_PAGE_DOWN then
      return
    elseif t.action ~= KeyMap.GN_LST_SELECT then
      return
    end
  end
  self.keyDown = true
  if t.action == KeyMap.GN_LST_CANCEL or t.action == KeyMap.CANCEL then
    if not self:GetCurrentCharacterIsDead() then
      self:HandleCloseButton()
    elseif DailyChallenge_IsDailyChallengeActive() then
      self:HandleCloseButton()
    else
      self:HandleCheckpointButton()
    end
  elseif t.action == KeyMap.GN_LST_SELECT then
    self:CallFlashFunction("_root.onSelectCurrentButton")
  elseif t.action == KeyMap.GN_LST_LT or t.action == KeyMap.LEFT then
    self:CallFlashFunction("_root.onSelectionLeft")
  elseif t.action == KeyMap.GN_LST_RT or t.action == KeyMap.RIGHT then
    self:CallFlashFunction("_root.onSelectionRight")
  elseif t.action == KeyMap.UP then
    self:CallFlashFunction("_root.onSelectionUp")
  elseif t.action == KeyMap.DOWN then
    self:CallFlashFunction("_root.onSelectionDown")
  elseif t.action == KeyMap.GN_LST_PAGE_UP then
    if self.tabHandle ~= UI.INVALID_UI_HANDLE then
      self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "onKeyDown", t)
      self:OnTabChanged("webstore")
    end
  elseif t.action == KeyMap.GN_LST_PAGE_DOWN then
    if self.tabHandle ~= UI.INVALID_UI_HANDLE then
      self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "onKeyDown", t)
      self:OnTabChanged("characters")
    end
  elseif t.action == KeyMap.GN_LST_NORTH then
    if self:GetCurrentCharacterIsDead() and not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
      self:IncrementSparksButton()
    end
  elseif t.action == KeyMap.GN_LST_WEST then
    if self:GetCurrentCharacterIsDead() then
      if self:GetCurrentSparks() >= self:GetReviveCost() then
        self.hitRevive = true
        self:HandleCloseButton()
      else
        self:ShowErrorPopup("IGP_AvatarUnavailable_Title", "IGP_AvatarUnavailable_Desc")
      end
    else
      self:HandleContinueButton()
    end
  elseif t.action == KeyMap.DEFAULT_LT and self:GetCurrentCharacterIsDead() and Players_HandleDeathInput(self.InstanceData.playerNum, 0) == false then
    return
  end
end

function VirtualReaderPC_Loadout:EnableTakeoverDeathRestartLegend()
  self.takeoverDeathRestartLegend = true
  self:SetButtonLegend(self:GetButtonLegend())
end

function VirtualReaderPC_Loadout:GetButtonLegend()
  if DailyChallenge_IsDailyChallengeActive() then
    if self:GetCurrentCharacterIsDead() then
      if not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
        return "Btn_Legend_Select,btn_legend_vrpc_revive,btn_legend_vrpc_purchase_sparks,btn_legend_exit"
      else
        return "Btn_Legend_Select,btn_legend_vrpc_revive,btn_legend_exit"
      end
    elseif not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
      return "Btn_Legend_Select,btn_legend_vrpc_purchase_sparks,btn_legend_exit"
    else
      return "Btn_Legend_Select,btn_legend_exit"
    end
  elseif self:GetCurrentCharacterIsDead() then
    local legend = "Btn_Legend_Select,btn_legend_vrpc_revive,"
    if not UI_IsPlalaGame() and not UI_IsTOGOOfflineGame() then
      legend = legend .. "btn_legend_vrpc_purchase_sparks,"
    end
    if Players_NumPlayers() > 1 then
      legend = legend .. "btn_legend_death_callforhelp,"
    end
    if Players_GetHostPlayerID() == self.InstanceData.playerNum then
      if self.takeoverDeathRestartLegend then
        legend = legend .. "btn_legend_death_restart"
      else
        legend = legend .. "btn_legend_vrpc_checkpoint"
      end
    end
    return legend
  elseif self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState == "ToyboxLoadoutPlay" then
      return "btn_legend_vrpc_continue"
    elseif onboardState == "ToyboxCharacterSlot" then
      return "Btn_Legend_Select"
    end
    return ""
  elseif self.launchLevelInfo ~= nil or self.continuePlaysetInfo ~= nil or self.loadUGCHandle ~= nil then
    return "Btn_Legend_Select,btn_legend_vrpc_continue,Btn_Legend_Back"
  elseif build == "TOYBOX_TOGO" and (platform == "TARGET_WIN32" or platform == "TARGET_WIN8") then
    return "Btn_Legend_Select,btn_legend_vrpc_continue,Btn_Legend_Back"
  else
    return "Btn_Legend_Select,Btn_Legend_Back"
  end
end

function VirtualReaderPC_Loadout:SaveSemiPersistentData(spTable)
end

function VirtualReaderPC_Loadout:ArrayContains(array, item)
  if array == nil or item == nil then
    return false
  end
  for i = 1, #array do
    if array[i] == item then
      return true
    end
  end
  return false
end

function VirtualReaderPC_Loadout:SetLaunchLevelInfo(launchInfo)
  self.launchLevelInfo = launchInfo
end

function VirtualReaderPC_Loadout:SetContinuePlaysetInfo(playsetInfo)
  self.continuePlaysetInfo = playsetInfo
end

function VirtualReaderPC_Loadout:SetLoadUGCHandle(loadHandle)
  self.loadUGCHandle = loadHandle
end

function VirtualReaderPC_Loadout:HandleContinueButton()
  if self.currentCharacter == nil then
    self:ShowErrorPopup("Scn_Loadout_SelectCharacterTitle", "Scn_Loadout_SelectCharacterDescription")
    return
  end
  local currentPlaySetBrand = VirtualReaderPC_GetBrandFromCurrentPlaySet()
  if currentPlaySetBrand ~= nil and currentPlaySetBrand ~= "" and self.currentCharacter.Name ~= nil and self.currentCharacter.Name ~= "" then
    local characterBrand = VirtualReaderPC_GetBrandFromName(self.currentCharacter.Name)
    if characterBrand == nil or characterBrand == "" or currentPlaySetBrand ~= characterBrand then
      self:ShowErrorPopup("Scn_Loadout_SelectPlaySetCharacterTitle", "Scn_Loadout_SelectPlaySetCharacterDescription")
      return
    end
  end
  self.hitContinue = true
  self:HandleCloseButton()
  if self.launchLevelInfo ~= nil then
    UI_LaunchLevel(self.launchLevelInfo.levelName, self.launchLevelInfo.saveTarget, self.launchLevelInfo.forceOnMinTime, self.launchLevelInfo.forceDuringPause, self.launchLevelInfo.forceAnyZone, self.launchLevelInfo.characterSelected)
    self.launchLevelInfo = nil
  end
  if self.continuePlaysetInfo ~= nil then
    UI_ContinuePlayset(self.continuePlaysetInfo.playsetName, self.continuePlaysetInfo.zoneName, self.continuePlaysetInfo.characterSelected)
    self.continuePlaysetInfo = nil
  end
  if self.loadUGCHandle ~= nil then
    local gameSaveLoadUGCHandle = UI.GetHandleFromName(self.loadUGCHandle, self.InstanceData.playerNum)
    if gameSaveLoadUGCHandle ~= UI.INVALID_UI_HANDLE then
      self:CallScreenFunctionByScreenName(self.loadUGCHandle, self.InstanceData.playerNum, "LoadLevel")
    end
    self.loadUGCHandle = nil
  end
end

function VirtualReaderPC_Loadout:HandleCloseButton()
  if not self.movieLoadedAndFocused then
    return
  end
  if self:IsOnboardTutorialActive() then
    local onboardState = UI_GetOnboardTutorialStateString()
    if onboardState ~= "LoadoutPlay" and onboardState ~= "ToyboxLoadoutPlay" then
      return
    elseif onboardState == "LoadoutPlay" then
      UI_SetOnboardTutorialState("Playset")
    elseif onboardState == "ToyboxLoadoutPlay" then
      UI_SetOnboardTutorialState("Toybox")
    end
  end
  if self.hitRevive and self:GetCurrentCharacterIsDead() and self:GetCurrentSparks() >= self:GetReviveCost() then
    UI_IncrementSparks(-self:GetReviveCost())
    if self.currentCharacter.SkuId ~= nil then
      Players_RemovePlayerDeathInfo(self.InstanceData.playerNum, self.currentCharacter.SkuId)
      self.forceAvatarChange = true
    end
  end
  if not self.hitContinue then
    if self.continuePlaysetInfo ~= nil then
      local playsetListHandle = UI.GetHandleFromName("PlaysetListWin32", 0)
      if playsetListHandle ~= UI.INVALID_UI_HANDLE then
        self:CallScreenFunctionByScreenName("PlaysetListWin32", self.InstanceData.playerNum, "CancelWorldSelectResultTimer")
      end
      local playsetSelectHandle = UI.GetHandleFromName("PlaysetSelectMenu", 0)
      if playsetSelectHandle ~= UI.INVALID_UI_HANDLE then
        self:CallScreenFunctionByScreenName("PlaysetSelectMenu", self.InstanceData.playerNum, "CancelWorldSelectResultTimer")
      end
    end
    if self.loadUGCHandle ~= nil then
      local gameSaveLoadUGCHandle = UI.GetHandleFromName(self.loadUGCHandle, self.InstanceData.playerNum)
      if gameSaveLoadUGCHandle ~= UI.INVALID_UI_HANDLE then
        self:CallScreenFunctionByScreenName(self.loadUGCHandle, self.InstanceData.playerNum, "SetScreenActive", true)
      end
      self.loadUGCHandle = nil
    end
  end
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "RequestExit")
    self.tabHandle = UI.INVALID_UI_HANDLE
  end
  VirtualReaderPC_Loadout.superClass().HandleCloseButton(self)
end

function VirtualReaderPC_Loadout:HandleCheckpointButton()
  if not self.movieLoadedAndFocused then
    return
  end
  if self.takeoverDeathRestartLegend then
    UI_ReturnToHub(self.InstanceData.playerNum)
  elseif self.currentCharacter ~= null and self.currentCharacter.SkuId ~= null then
    VirtualReaderPC_AvatarCheckpointRespawn(self.InstanceData.playerNum, self.currentCharacter.SkuId)
  end
  if self.tabHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "RequestExit")
    self.tabHandle = UI.INVALID_UI_HANDLE
  end
  VirtualReaderPC_Loadout.superClass().HandleCloseButton(self)
end

function VirtualReaderPC_Loadout:ShowErrorPopup(title, body)
  self.bIsPopupOpen = true
  self.ErrorPopup.parent = self
  self.ErrorPopup.option = nil
  self.ErrorPopup.title = title
  self.ErrorPopup.body = body
  self.ErrorPopup.list = {
    "SharedText_OK"
  }
  
  function self.ErrorPopup.onClose()
    self:CloseErrorPopup()
  end
  
  self.errorPopupHandle = self:AddScreen({
    screenName = "Popup",
    playerNum = self.InstanceData.playerNum,
    dataProvider = self.ErrorPopup
  })
  self:DisableTabs(true)
end

function VirtualReaderPC_Loadout:CloseErrorPopup()
  self:DisableTabs(false)
  self.bIsPopupOpen = false
end

function VirtualReaderPC_Loadout:GetReviveCost()
  return 1000
end

function VirtualReaderPC_Loadout:GetExpirationDate()
end

function VirtualReaderPC_Loadout:RefreshScreen()
  self:RefreshSparks()
end

function VirtualReaderPC_Loadout:GoToUpSellPC(itemName)
  VirtualReaderPC_Loadout.superClass().GoToUpSellPC(self, itemName)
  self:CallFlashFunction("_root.DeactivateScreen")
end

return VirtualReaderPC_Loadout
