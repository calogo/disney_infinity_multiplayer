if validateLuas then
  require("LuaValidator")
end
local ContainerData = require("ContainerData")
local ClassFactory = require("ClassFactory")
local ContainerBase = require("ContainerBase")
require("CachedScreenData")
require("FSM")
require("FSM_Standard")

local function fixVRPositions(cd)
  if not cd or not cd.children then return end
  local screens = {
    "VirtualReaderPC_GridCharacter",
    "VirtualReaderPC_GridHexCoin",
    "VirtualReaderPC_GridRoundCoin",
    "VirtualReaderPC_Loadout",
    "VirtualReaderPC_Tabs",
    "VirtualReaderPC_CharacterInspect",
    "VirtualReaderPC_CoreAbilities",
    "VirtualReaderPC_Webstore",
    "UpSellPC",
    "UpSell"
  }
  for _, name in ipairs(screens) do
    local entry = cd.children[name]
    if entry then
      if not entry.position then
        entry.position = {
          Single = { view0 = {0.5, 0.5} },
          combined = { view0 = {0.5, 0.5}, view1 = {0.5, 0.5} },
          horizontal = { view0 = {0.5, 0.5}, view1 = {0.5, 0.5} }
        }
      end
      local splitY = 0.58
      local targetX0 = 0.25
      local targetX1 = 0.75
      if name == "VirtualReaderPC_Tabs" then
        splitY = 0.36
      elseif name == "VirtualReaderPC_CharacterInspect" or name == "VirtualReaderPC_CoreAbilities" or name == "UpSellPC" or name == "UpSell" then
        splitY = 0.335
        targetX0 = 0.025
        targetX1 = 0.025
      end
      entry.position.vertical = {
        view0 = {targetX0, splitY},
        view1 = {targetX1, splitY}
      }
    end
  end
end
fixVRPositions(ContainerData)

Container = ClassFactory.CreateClass("Container", ContainerBase)
Container.ScreenDefinition = {
  SWF = {
    P1 = "Container",
    DEVICE_3x2 = "Container_3x2",
    DEVICE_16x10 = "Container_16x10",
    DEVICE_5x3 = "Container_5x3",
    DEVICE_16x9 = "Container_16x9",
    DEVICE_16x9_64 = "Container_16x9_64"
  },
  layer = "Container",
  priority = 50,
  needsInput = false
}
Container.numberOfPlayers = 1
Container.aspectRatio = 1
Container.orientation = 1
Container.containerDB = nil
Container.containerTable = nil
Container.rowIterator = 0
Container.tableRows = 0
Container.tableColumns = 0
Container.HORIZONTAL = "horizontal"
Container.VERTICAL = "vertical"
Container.COMBINED = "combined"
Container.numPlayers = 1
Container.viewport1PlayerID = -1
Container.ContainerData = ContainerData

function Container:determineSplit()
  local isSplit = (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (self.numberOfPlayers and self.numberOfPlayers > 1)
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    return "vertical"
  end
  return "single"
end

function Container:ContainerLoaded()
  UI.DefaultContainerLoaded()
end

function Container:SetPosition(handle, x, y, viewport)
  local vp = viewport or 0
  self:CallFlashFunction("_root.AddArgDataKeyValue", "viewport", vp)
  local viewportX, viewportY = self:MapPositionToLayout(tonumber(x), tonumber(y), handle)
  self:CallFlashFunction("_root.SetPosition", handle, viewportX, viewportY)
  self:CallFlashFunction("_root.HandleViewportChange", handle)
end

return Container
