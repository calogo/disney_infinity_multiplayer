local ava = require("AvaHelpers")
local VirtualReaderPC = require("VirtualReaderPC")
local infHelpers = require("InfinityHelpers")
local ClassFactory = require("ClassFactory")
local Screen = require("Screen")
UpSellPC = ClassFactory.CreateClass("UpSellPC", Screen)
UpSellPC.ScreenDefinition = {
  SWF = "UpSell/UpSellPC",
  layer = "main",
  priority = 51,
  needsInput = true,
  doLuaInput = true
}

function UpSellPC:init()
  UpSellPC.superClass().init(self)
end

function UpSellPC:onEnter()
  UpSellPC.superClass().onEnter(self)
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "HideVirtualReaderTabs")
  end
  self.currentItemData = {
    name = "",
    image = "",
    description = "",
    price = "",
    sku = "",
    steamappid = ""
  }
  self.listData = {}
  self.numRows = 1
  self.numColumns = 4
  self.currentIndex = 1
  self.startId = 1
  self.GridButtonTemplateWidth = 240
  self.GridButtonTemplateHeight = 209
  self.GridButtonImageWidth = 110
  self.GridButtonImageHeight = 110
  self.GridButtonLargeImageWidth = 115
  self.GridButtonLargeImageHeight = 133
  self.selectedId = 1
  self.selectedIndex = tonumber(self.selectedId)
  if self.useMovementTable == nil or self.movementTable == nil or 1 > #self.movementTable then
    self.useMovementTable = false
    self.movementTable = nil
  end
  self.quitLevel = false
  self.pausedForUpsell = false
  self:SetActionMap("GN_LST_SELECT,GN_LST_CANCEL,GRD_UP,GRD_DOWN,GRD_LEFT,GRD_RIGHT,RIGHT,LEFT,UP,DOWN,GN_LST_WEST,GN_LST_NORTH,GN_LST_PAGE_UP,GN_LST_PAGE_DOWN,LT,RT,START")
end

function UpSellPC:onExit()
  if self.quitLevel == true then
    Pause_ExitGame()
  elseif self.pausedForUpsell then
    Pause_UnPauseFromPausedScreenIfPaused(self.InstanceData.playerNum)
  end
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "ShowVirtualReaderTabs")
  end
  if self.screenCallbackName ~= nil then
    local callbackHandle = UI.GetHandleFromName(self.screenCallbackName, self.InstanceData.playerNum)
    if callbackHandle ~= UI.INVALID_UI_HANDLE then
      self:CallScreenFunctionByScreenName(self.screenCallbackName, self.InstanceData.playerNum, "ReturnFromExclusiveOverlayScreen")
    end
    if self.screenCallbackName == "SkillTreeGrid_IN3" then
      UpSellPC.superClass().onExit(self)
      return
    end
  end
  self:RefreshScreens()
  if self.pausedForUpsell then
    UI_HideCursor()
  end
  UpSellPC.superClass().onExit(self)
end

function UpSellPC:PauseForUpsell()
  if not System_InFrontEndOld() then
    Pause_PauseGame(self.InstanceData.playerNum, false, false)
  end
  UI_ShowCursor()
  self.pausedForUpsell = true
end

function UpSellPC:MovieLoaded()
  self:SetButtonLegend(self:GetButtonLegend())
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = 0.025
    local targetY = 0.335
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen then
        local entry = containerScreen.ContainerData and containerScreen.ContainerData.children and containerScreen.ContainerData.children[self.InstanceData.luaName]
        if entry and containerScreen.AdjustForViewportChange then
          containerScreen:AdjustForViewportChange(self.InstanceData.luaName, entry, pNum)
        elseif containerScreen.SetPosition then
          containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY, pNum)
        end
      end
    end
  else
    self:CallFlashFunction("_root.CenterGrid")
  end
end

function UpSellPC:GetButtonLegend()
  if self.listData[self.selectedIndex].hasTrailer then
    return "Btn_Legend_Select,Btn_Legend_VRPC_Purchase,Btn_Legend_VRPC_Trailer,Btn_Legend_Back"
  else
    return "Btn_Legend_Select,Btn_Legend_VRPC_Purchase,Btn_Legend_Back"
  end
end

function UpSellPC:SetScreenCallbackName(parentScreenName)
  self.screenCallbackName = parentScreenName
end

function UpSellPC:SetItemInfo(itemName)
  self.listData = {}
  self.itemInfo = VirtualReaderPC_GetItemByName(itemName, self.InstanceData.playerNum)
  if self.itemInfo ~= nil then
    if not VirtualReaderPC_IsItemHexCoin(self.itemInfo.Name) then
      self:SetCurrentItemData(self.itemInfo)
    end
    self:SetGridData()
    self:CallFlashFunction("_root.Rebuild")
  else
    print("WARNING:  UpSellPC:SetItemInfo no item info found" .. itemName)
  end
end

function UpSellPC:SetCurrentItemData(itemData)
  if itemData ~= nil then
    self.currentItemData.id = 1
    self.currentItemData.name = itemData.Name
    self.currentItemData.image = VirtualReaderPC:GetIconPath(itemData.Name, itemData.Icon)
    self.currentItemData.description = itemData.Description
    self.currentItemData.price = ""
    if itemData.Price ~= nil and itemData.Price ~= "" then
      self.currentItemData.price = itemData.Price
    end
    self.currentItemData.sku = itemData.Sku
    self.currentItemData.steamappid = itemData.SteamDLCAppId
    self.currentItemData.hasLargeIcon = VirtualReaderPC:HasLargeIcon(self.currentItemData.name)
    local imageWidth = self.GridButtonImageWidth
    local imageHeight = self.GridButtonImageHeight
    if self.currentItemData.hasLargeIcon then
      imageWidth = self.GridButtonLargeImageWidth
      imageHeight = self.GridButtonLargeImageHeight
    end
    self.currentItemData.imageWidth = imageWidth
    self.currentItemData.imageHeight = imageHeight
    self.currentItemData.hasTrailer = VirtualReaderPC_IsItemAvatar(self.currentItemData.name) and itemData.VideoLink
    self:CallFlashFunction("_root.SetCurrentInfo", self.currentItemData.name, self.currentItemData.description, self.currentItemData.image, self.currentItemData.hasLargeIcon, self.currentItemData.price, self.currentItemData.hasTrailer)
    local selected = true
    self:AddGridButton(self.currentItemData.id, self.currentItemData.name, self.currentItemData.image, self.currentItemData.imageWidth, self.currentItemData.imageHeight, self.currentItemData.hasLargeIcon, self.currentItemData.description, self.currentItemData.price, self.currentItemData.sku, self.currentItemData.steamappid, self.currentItemData.hasTrailer, selected)
  end
end

function UpSellPC:SetGridData()
  if self.itemInfo ~= nil then
    local bSetFirstBundleAsCurrentItem = VirtualReaderPC_IsItemHexCoin(self.itemInfo.Name)
    local BundlePackArray = VirtualReaderPC_GetUpsellBundles(self.itemInfo.Name, self.InstanceData.playerNum)
    if BundlePackArray ~= nil then
      for i = 1, #BundlePackArray do
        local info = BundlePackArray[i]
        if info ~= nil then
          if bSetFirstBundleAsCurrentItem and i == 1 then
            self:SetCurrentItemData(info)
            if #BundlePackArray == 1 then
              self:CallFlashFunction("_root.ShowSimilarBundles", false)
            end
          else
            local gridIndex = i
            if not bSetFirstBundleAsCurrentItem then
              gridIndex = i + 1
            end
            local id = gridIndex
            local name = info.Name
            local image = VirtualReaderPC:GetIconPath(info.Name, info.Icon)
            local description = info.Description
            local price = ""
            if info.Price ~= nil and info.Price ~= "" then
              price = info.Price
            end
            local sku = info.Sku
            local steamappid = info.SteamDLCAppId
            local hasLargeIcon = VirtualReaderPC:HasLargeIcon(name)
            local imageWidth = self.GridButtonImageWidth
            local imageHeight = self.GridButtonImageHeight
            if hasLargeIcon then
              imageWidth = self.GridButtonLargeImageWidth
              imageHeight = self.GridButtonLargeImageHeight
            end
            local hasTrailer = VirtualReaderPC_IsItemAvatar(name) and info.VideoLink
            local selected = false
            self:AddGridButton(id, name, image, imageWidth, imageHeight, hasLargeIcon, description, price, sku, steamappid, hasTrailer, selected)
          end
        end
      end
    else
      self:CallFlashFunction("_root.ShowSimilarBundles", false)
    end
  end
end

function UpSellPC:AddGridButton(id, name, image, imageWidth, imageHeight, hasLargeIcon, description, price, sku, steamappid, hasTrailer, selected)
  if not self.listData then
    self.listData = {}
  end
  local t = self.listData
  t[#t + 1] = {
    id = id,
    name = name,
    image = image,
    imageWidth = imageWidth,
    imageHeight = imageHeight,
    hasLargeIcon = hasLargeIcon,
    description = description,
    price = price,
    sku = sku,
    steamappid = steamappid,
    hasTrailer = hasTrailer,
    selected = selected,
    parentGridActive = true,
    effectName = id,
    widgetType = "Button",
    buttonState = "",
    buttonLegend = "Btn_Legend_Select,Btn_Legend_Back",
    get = nil,
    set = nil
  }
end

function UpSellPC:Rebuild(t)
  self.selectedId = self.startId
  self.selectedIndex = tonumber(self.selectedId)
  self:CallFlashFunction("_root.Rebuild")
  self:SetButtonLegend(self:GetButtonLegend())
end

function UpSellPC:GetItems(id)
  if #self.listData == 0 then
    return nil
  end
  local list = {}
  for i = 1, #self.listData do
    table.insert(list, tostring(self.listData[i].id))
  end
  return list
end

function UpSellPC:GetElementClassName(id)
  if id == nil then
    return
  end
  local data = self.listData[tonumber(id)]
  if data == nil or data.widgetType == nil then
    return "Button"
  else
    return data.widgetType
  end
end

function UpSellPC:SelectedItemChanged(id, visibleIndex)
  self.selectedId = id
  self.selectedIndex = tonumber(self.selectedId)
  self.currentIndex = tonumber(self.selectedId)
  self:SetButtonLegend(self:GetButtonLegend())
end

function UpSellPC:SelectGridItem()
  Sfx_Play2D("GenericList_Cancel")
  local option = self:CallFlashFunction("_root.GetCurrentElement")
  if option ~= nil and option ~= "" then
    local lastData = self.listData[tonumber(self.currentItemData.id)]
    if lastData ~= nil then
      lastData.selected = false
      self:CallFlashFunction("_root.RebuildElement", self.currentItemData.id)
    end
    local gridItemData = self.listData[tonumber(option)]
    self.currentItemData.id = gridItemData.id
    self.currentItemData.name = gridItemData.name
    self.currentItemData.image = gridItemData.image
    self.currentItemData.imageWidth = gridItemData.imageWidth
    self.currentItemData.imageHeight = gridItemData.imageHeight
    self.currentItemData.hasLargeIcon = gridItemData.hasLargeIcon
    self.currentItemData.description = gridItemData.description
    self.currentItemData.price = gridItemData.price
    self.currentItemData.sku = gridItemData.sku
    self.currentItemData.steamappid = gridItemData.steamappid
    self.currentItemData.hasTrailer = gridItemData.hasTrailer
    local newData = self.listData[tonumber(self.currentItemData.id)]
    if newData ~= nil then
      newData.selected = true
      newData.fromMouseClick = true
      self:CallFlashFunction("_root.RebuildElement", self.currentItemData.id)
      newData.fromMouseClick = false
    end
    if lastData.id ~= newData.id then
      self:CallFlashFunction("_root.SetCurrentInfo", self.currentItemData.name, self.currentItemData.description, self.currentItemData.image, self.currentItemData.hasLargeIcon, self.currentItemData.price, self.currentItemData.hasTrailer)
    end
    self:SetButtonLegend(self:GetButtonLegend())
  end
end

function UpSellPC:PressedPurchaseButton(id)
  if platform == "TARGET_WIN32" then
    local pcSKU = self.currentItemData.sku
    if pcSKU ~= nil and pcSKU ~= "" then
      if UI_IsSteamGame() and self.currentItemData.steamappid ~= nil and self.currentItemData.steamappid ~= "" then
        VirtualReaderPC_OpenSteamStoreOverlay(self.currentItemData.steamappid)
      else
        UI_LaunchDisneyStore(pcSKU)
      end
    end
  elseif platform == "TARGET_WIN8" and self.currentItemData.sku ~= nil and self.currentItemData.sku ~= "" and self.currentItemData.name ~= nil then
    VirtualReaderPC_Purchase(self.currentItemData.sku, self.currentItemData.name)
  end
end

function UpSellPC:PressedTrailerButton(id)
  local TrailerItem = {}
  TrailerItem = VirtualReaderPC_GetItemByName(self.currentItemData.name, self.InstanceData.playerNum)
  if TrailerItem ~= nil and VirtualReaderPC_IsItemAvatar(TrailerItem.Name) then
    PlayBinkMovie(TrailerItem.VideoLink, true, 0, true)
  end
end

function UpSellPC:RefreshScreens()
  local handle = UI.GetHandleFromName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_GridRoundCoin", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_GridRoundCoin", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_GridHexCoin", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_GridHexCoin", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_Loadout", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Loadout", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_CoreAbilities", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_CoreAbilities", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("QuestTracker", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("QuestTracker", self.InstanceData.playerNum, "RefreshScreen")
  end
  handle = UI.GetHandleFromName("VirtualReaderPC_Webstore", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Webstore", self.InstanceData.playerNum, "RefreshScreen")
  end
end

function UpSellPC:GetNumRows()
  return self.numRows
end

function UpSellPC:GetNumColumns()
  return self.numColumns
end

function UpSellPC:UseMovementTable()
  return self.useMovementTable
end

function UpSellPC:GetMovementIndex(id, dir)
  local index = -1
  if self.useMovementTable ~= nil and id <= #self.movementTable and 0 <= id then
    if dir == "up" then
      index = self.movementTable[id].up
    elseif dir == "down" then
      index = self.movementTable[id].down
    elseif dir == "left" then
      index = self.movementTable[id].left
    elseif dir == "right" then
      index = self.movementTable[id].right
    else
      index = -1
    end
  end
  return index
end

function UpSellPC:GetStartID(id)
  if self.listData == nil or #self.listData == 0 then
    return nil
  end
  return self.startId
end

function UpSellPC:GetElementData(id, field)
  return self:GetItemData(id, field)
end

function UpSellPC:GetGridButtonTemplateWidth()
  return self.GridButtonTemplateWidth
end

function UpSellPC:GetGridButtonTemplateHeight()
  return self.GridButtonTemplateHeight
end

function UpSellPC:GetItemData(id, field)
  if id == nil then
    return
  end
  local data
  data = self.listData[tonumber(id)]
  if data == nil then
    return nil
  end
  if field == "value" then
    if data.get then
      return data.get(self, id)
    else
      print("WARNING:  UpSellPC:GetItemData get field on ID " .. id)
      return nil
    end
  else
    if data[field] == nil then
      print("WARNING:  UpSellPC:GetItemData is asking for " .. field .. " on ID " .. id)
    end
    return data[field]
  end
end

function UpSellPC:onKeyDown(t)
  if t.action == KeyMap.GN_LST_CANCEL or t.action == KeyMap.CANCEL then
    self:RequestExit()
  elseif t.action == KeyMap.GN_LST_SELECT then
    self:SelectGridItem()
  elseif t.action == KeyMap.GRD_UP then
    self:CallFlashFunction("_root.MoveGrid", 0)
  elseif t.action == KeyMap.GRD_DOWN then
    self:CallFlashFunction("_root.MoveGrid", 1)
  elseif t.action == KeyMap.GRD_LEFT then
    self:CallFlashFunction("_root.MoveGrid", 2)
  elseif t.action == KeyMap.GRD_RIGHT then
    self:CallFlashFunction("_root.MoveGrid", 3)
  elseif t.action == KeyMap.GN_LST_WEST then
    self:PressedPurchaseButton()
  elseif t.action == KeyMap.GN_LST_NORTH then
    self:PressedTrailerButton()
  end
end

function UpSellPC:SetUpSellItem(item)
  self:SetItemInfo(item)
end

function UpSellPC:QuitLevelOnExit()
  print("QuitLevelOnExit is true")
  self.quitLevel = true
end

return UpSellPC
