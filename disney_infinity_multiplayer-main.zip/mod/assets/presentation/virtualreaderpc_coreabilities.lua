local ava = require("AvaHelpers")
local infHelpers = require("InfinityHelpers")
local ClassFactory = require("ClassFactory")
local KeyMap = require("KeyMap")
local VirtualReaderPC = require("VirtualReaderPC")
VirtualReaderPC_CoreAbilities = ClassFactory.CreateClass("VirtualReaderPC_CoreAbilities", VirtualReaderPC)
VirtualReaderPC_CoreAbilities.ScreenDefinition = {
  SWF = "VirtualReader/VirtualReaderPC_CoreAbilities",
  layer = "main",
  priority = 7,
  doLuaInput = true
}

function VirtualReaderPC_CoreAbilities:init()
  VirtualReaderPC_CoreAbilities.superClass().init(self)
end

function VirtualReaderPC_CoreAbilities:MovieLoaded()
  VirtualReaderPC_CoreAbilities.superClass().MovieLoaded(self)
  local pNum = (self.InstanceData and self.InstanceData.playerNum) or 0
  local isSplit = (pNum == 1)
    or (UI_IsGamePlayVerticalSplit and UI_IsGamePlayVerticalSplit())
    or (_G.Players_NumPlayers and _G.Players_NumPlayers() > 1)
  if isSplit then
    self:CallFlashFunction("SetScale", 0.5, 0.5)
    self:CallFlashFunction("_root.SetScale", 0.5, 0.5)
    local targetX = 0.025
    local targetY = 0.335
    self:CallFlashFunction("SetPosition", targetX, targetY)
    local containerHandle = UI.GetDefaultContainerHandle(UI.DI_STANDARD)
    if containerHandle ~= UI.INVALID_UI_HANDLE then
      local containerScreen = UI.GetScreenFromScreenHandle(containerHandle)
      if containerScreen then
        local entry = containerScreen.ContainerData and containerScreen.ContainerData.children and containerScreen.ContainerData.children[self.InstanceData.luaName]
        if entry and containerScreen.AdjustForViewportChange then
          containerScreen:AdjustForViewportChange(self.InstanceData.luaName, entry, pNum)
        elseif containerScreen.SetPosition then
          containerScreen:SetPosition(self.InstanceData.handle, targetX, targetY, pNum)
        end
      end
    end
  end
  self.movieLoadedAndFocused = true
end

function VirtualReaderPC_CoreAbilities:onEnter()
  self.currentAbility = 0
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "HideVirtualReaderTabs")
  end
  VirtualReaderPC_CoreAbilities.superClass().onEnter(self)
end

function VirtualReaderPC_CoreAbilities:onExit()
  local handle = UI.GetHandleFromName("VirtualReaderPC_Tabs", self.InstanceData.playerNum)
  if handle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunctionByScreenName("VirtualReaderPC_Tabs", self.InstanceData.playerNum, "ShowVirtualReaderTabs")
  end
  VirtualReaderPC_CoreAbilities.superClass().onExit(self)
end

function VirtualReaderPC_CoreAbilities:SetCharacterInfo(characterName)
  self.characterInfo = VirtualReaderPC_GetItemByName(characterName, self.InstanceData.playerNum)
  self.coreAbilities = VirtualReaderPC_GetAvatarAbilitiesByName(self.characterInfo.ProgressionTree)
  self:CallFlashFunction("_root.SetCharacterInfo", self.characterInfo)
  if self.coreAbilities.abilities == nil then
    print("No ability data found for current character.")
    return
  end
  local maxAbilityCount = 4
  for abilityIndex = 1, maxAbilityCount do
    if abilityIndex <= #self.coreAbilities.abilities then
      self.coreAbilities.abilities[abilityIndex].SkillScreen = "ui/skillscreenshots/" .. infHelpers:MangleIconName(self.coreAbilities.abilities[abilityIndex].SkillScreen)
      self.coreAbilities.abilities[abilityIndex].SkillIndex = abilityIndex - 1
      self:CallFlashFunction("_root.SetAbilityInfo", self.coreAbilities.abilities[abilityIndex])
    else
      self:CallFlashFunction("_root.DisableAbilityButton", abilityIndex - 1)
    end
  end
  self:AppendActionMap("GN_LST_NORTH")
  self:SetSelectedAbility(self.currentAbility)
end

function VirtualReaderPC_CoreAbilities:GetButtonLegend()
  if self.characterInfo ~= nil and self.characterInfo.IsLocked then
    if self.characterInfo.IsTrialPlayable then
      if not UI_IsPlalaGame() then
        return "Btn_Legend_VRPC_Try,Btn_Legend_VRPC_Unlock,Btn_Legend_Back"
      else
        return "Btn_Legend_VRPC_Try,Btn_Legend_Back"
      end
    elseif not UI_IsPlalaGame() then
      return "Btn_Legend_VRPC_Unlock,Btn_Legend_Back"
    else
      return "Btn_Legend_Back"
    end
  else
    return "btn_legend_vrpc_select,Btn_Legend_Back"
  end
end

function VirtualReaderPC_CoreAbilities:onKeyDown(t)
  if not self.movieLoadedAndFocused then
    return
  end
  if t.action == KeyMap.GN_LST_SELECT then
    self:SelectOrUnlockCharacter()
  elseif t.action == KeyMap.GN_LST_CANCEL then
    self:HandleCloseButton()
  elseif t.action == KeyMap.UP then
    self:SetSelectedAbility(self.currentAbility - 1)
  elseif t.action == KeyMap.GN_LST_NORTH then
    if not UI_IsPlalaGame() and self.characterInfo.IsTrialPlayable then
      self:SelectCharacter()
    end
  elseif t.action == KeyMap.DOWN then
    self:SetSelectedAbility(self.currentAbility + 1)
  end
end

function VirtualReaderPC_CoreAbilities:SelectOrUnlockCharacter()
  if self.characterInfo.Name ~= nil then
    if UI_IsPlalaGame() then
      if not self.characterInfo.IsLocked or self.characterInfo.IsTrialPlayable then
        self:SelectCharacter()
      end
    elseif self.characterInfo.IsLocked then
      self:GoToUpSellPC(self.characterInfo.Name)
    else
      self:SelectCharacter()
    end
  end
end

function VirtualReaderPC_CoreAbilities:GoToUpSellPC(itemName)
  VirtualReaderPC_CoreAbilities.superClass().GoToUpSellPC(self, itemName)
  self:CallFlashFunction("_root.DeactivateScreen")
end

function VirtualReaderPC_CoreAbilities:SelectCharacter()
  VirtualReaderPC_SetCurrentCharacter(self.characterInfo.SkuId)
  local GridCharacterSelectHandle = UI.GetHandleFromName("VirtualReaderPC_GridCharacter", self.InstanceData.playerNum)
  if GridCharacterSelectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(GridCharacterSelectHandle, "ExitScreen")
  end
  local TrialCharactersSelectHandle = UI.GetHandleFromName("TrialCharacters", self.InstanceData.playerNum)
  if TrialCharactersSelectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(TrialCharactersSelectHandle, "ExitScreen")
  end
  local CharacterInspectHandle = UI.GetHandleFromName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum)
  if CharacterInspectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(CharacterInspectHandle, "ExitScreen")
  end
  self:ExitScreen()
  self:ReturnToLoadout()
end

function VirtualReaderPC_CoreAbilities:GetAbilityCount()
  return self.coreAbilities.abilityCount
end

function VirtualReaderPC_CoreAbilities:SetSelectedAbility(index)
  if self.coreAbilities.abilities == nil then
    print("No ability data found for current character.")
    return
  end
  if index + 1 <= #self.coreAbilities.abilities and 1 <= index + 1 then
    self.currentAbility = index
    self:CallFlash("_root.ShowAbilityDetails", self.coreAbilities.abilities[index + 1], index)
  end
end

function VirtualReaderPC_CoreAbilities:HandleCloseButton()
  if not self.movieLoadedAndFocused then
    return
  end
  local CharacterInspectHandle = UI.GetHandleFromName("VirtualReaderPC_CharacterInspect", self.InstanceData.playerNum)
  if CharacterInspectHandle ~= UI.INVALID_UI_HANDLE then
    self:CallScreenFunction(CharacterInspectHandle, "ReturnFromExclusiveOverlayScreen")
  end
  self:ExitScreen()
end

function VirtualReaderPC_CoreAbilities:RefreshScreen()
  self:SetCharacterInfo(self.characterInfo.Name)
  self:SetButtonLegend(self:GetButtonLegend())
end

return VirtualReaderPC_CoreAbilities
