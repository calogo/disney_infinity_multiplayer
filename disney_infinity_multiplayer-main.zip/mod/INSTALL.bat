@echo off
REM Installer for the Disney Infinity 3.0 (PC/Steam) Local Co-op mod.
REM Copy this whole folder's files into the game folder (where DisneyInfinity3.exe is),
REM then run this .bat.
setlocal
cd /d "%~dp0"

if not exist "coop_bink2w32.dll" (
  echo [ERROR] coop_bink2w32.dll not found next to this installer.
  pause & exit /b 1
)
if not exist "bink2w32.dll" (
  echo [ERROR] bink2w32.dll not found. Copy this installer INTO the game folder
  echo         ^(where DisneyInfinity3.exe is^) and run it again.
  pause & exit /b 1
)

if exist "bink2w32_orig.dll" (
  echo Original already backed up ^(bink2w32_orig.dll^). Leaving it.
) else (
  ren "bink2w32.dll" "bink2w32_orig.dll"
  echo Original backed up as bink2w32_orig.dll
)

copy /Y "coop_bink2w32.dll" "bink2w32.dll" >nul

REM Back up and install presentation UI scripts
if exist "assets\presentation" (
  echo Installing split-screen presentation UI scripts...
  for %%F in (container.lua virtualreaderpc_gridcharacter.lua virtualreaderpc_gridbase.lua virtualreaderpc_loadout.lua virtualreaderpc_tabs.lua virtualreaderpc_characterinspect.lua virtualreaderpc_coreabilities.lua upsellpc.lua virtualreaderpc.lua) do (
    if exist "assets\presentation\%%F" (
      if not exist "assets\presentation\%%F.coop_orig" (
        copy /Y "assets\presentation\%%F" "assets\presentation\%%F.coop_orig" >nul
      )
    )
  )
)

echo.
echo [OK] Mod installed successfully.
echo Launch the game, enter a Toy Box or a Play Set with 2 controllers,
echo press START on controller 2 to join Player 2.
echo Press LB+RB together on controller 2 to change Player 2's character,
echo or open the in-game Character Selection menu with Player 2's controller.
echo To uninstall: run UNINSTALL.bat
pause
