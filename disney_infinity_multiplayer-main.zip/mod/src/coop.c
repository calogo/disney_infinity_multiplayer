// DI3 Local Co-op mod — proxy bink2w32.dll
// Reenvia todos los exports al bink2w32 original (bink2w32_orig.dll)
// y lanza un hilo que, al pulsar START en el mando 2, activa el co-op local.
// Solo memoria del proceso en runtime. No toca saves, red ni logros. Reversible.
#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

#define XI_START 0x0010

static HINSTANCE g_self;
static char g_log[MAX_PATH];

static void L(const char* fmt, ...){
    FILE* f = fopen(g_log, "a");
    if(!f) return;
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f); fclose(f);
}

// ============================ SECUENCIA CO-OP ============================
#define RVA(x) ((x) - 0x400000)
static void* game_base(void){ return (void*)GetModuleHandleA(NULL); }
static DWORD gp(void* base, DWORD ghidra){ return (DWORD)((BYTE*)base + RVA(ghidra)); }
static int mem_ok(void* p, SIZE_T n, int write);

// scan de heap para el gameLoop (con resolucion rapida por puntero estatico primero)
static void* find_gameloop(void* base){
    void* pContainer = *(void**)((BYTE*)base + 0x1E5F484);
    if(pContainer && mem_ok(pContainer, 0x20, 0)){
        void* loop = *(void**)((BYTE*)pContainer + 0x10);
        if(loop && mem_ok(loop, 4, 0)){
            DWORD vt0 = gp(base, 0x1D4418C);
            if(*(DWORD*)loop == vt0){
                return loop;
            }
        }
    }

    DWORD vt0  = gp(base, 0x1D4418C);
    DWORD vt58 = gp(base, 0x1D44180);
    DWORD vt308= gp(base, 0x1D44174);
    DWORD vt378= gp(base, 0x1D43F88);
    MEMORY_BASIC_INFORMATION mbi;
    BYTE* p = NULL;
    while(VirtualQuery(p, &mbi, sizeof(mbi)) == sizeof(mbi)){
        BYTE* region = (BYTE*)mbi.BaseAddress;
        SIZE_T sz = mbi.RegionSize;
        if(mbi.State==MEM_COMMIT && !(mbi.Protect & (PAGE_GUARD|PAGE_NOACCESS)) &&
           (mbi.Protect==PAGE_READWRITE || mbi.Protect==PAGE_WRITECOPY)){
            for(SIZE_T off=0; off+0x37C <= sz; off+=4){
                if(*(DWORD*)(region+off) == vt0){
                    BYTE* o = region+off;
                    if(*(DWORD*)(o+0x58)==vt58 && *(DWORD*)(o+0x308)==vt308 && *(DWORD*)(o+0x378)==vt378){
                        return o;
                    }
                }
            }
        }
        p = region + sz;
    }
    return NULL;
}

typedef void (__thiscall *dropin_t)(void*, int);
static int g_coop_done = 0;
static int g_active = 0;         // materializacion activa (tras drop-in)
static int g_hooks_done = 0;
static void run_coop(void);
static void install_hooks(void* base);

// ---- carga de modelo del personaje de P2 (ruta ActivateChanges) ----
typedef void (__thiscall *b73060_fn_t)(void* self, int playerId, void* item, int force);
static b73060_fn_t g_orig_b73060 = NULL;
static void* g_p2_item = 0;             // puntero de item resuelto para el sku actual de P2
static void* g_p2_current_item = 0;     // ultimo item aplicado a P2
static void* g_tramp_b73060 = 0;
static volatile int g_p2_swap_pending = 0; // swap pendiente (ejecutar en hilo principal)
static volatile DWORD g_p2_pending_sku = 0; // SKU recien elegido en menu por P2 (antes de confirmar)
static void* g_p2_avatar = NULL;            // puntero al avatar de P2 para forzar cuerpo solido
static volatile int g_p1_swap_pending = 0; // swap pendiente P1 (descongelar manager para spawn)
static volatile int g_p1_swap_frames = 0;  // contador de frames para mantener descongelado
static volatile DWORD g_p1_sku = 0;        // SKU activo de P1
static volatile DWORD g_p1_pending_sku = 0; // SKU recien elegido en menu por P1

// ---- lista para el CAMBIADOR de personaje de P2 (Star Wars primero) ----
typedef struct { const char* name; DWORD sku; } chardef_t;
static const chardef_t g_chars[] = {
    {"Ahsoka",0xf430b},{"Anakin",0xf4308},{"ObiWan",0xf4309},{"Yoda",0xf430a},{"DarthMaul",0xf430c},
    {"Luke",0xf430e},{"HanSolo",0xf430f},{"Leia",0xf4310},{"Chewbacca",0xf4311},{"Vader",0xf4312},{"BobaFett",0xf4313},
    {"Ezra",0xf4314},{"Kanan",0xf4315},{"Sabine",0xf4316},{"Zeb",0xf4317},
    {"CaptainAmerica",0xf42a4},{"Hulk",0xf42a5},{"Ironman",0xf42a6},{"Spiderman",0xf42ab},{"Thor",0xf42a7},
    {"BlackPanther",0xf4336},{"Groot",0xf42a8},{"Rocket",0xf42a9},{"Venom",0xf42b3},
    {"ClassicMickey",0xf431d},{"Elsa",0xf4259},{"Aladdin",0xf42b5},{"Stitch",0xf42b6},{"Maleficent",0xf42b9},
    {"JackSparrow",0xf4243},{"Woody",0xf4250},{"Buzz",0xf4248},{"Mulan",0xf431f},
};
#define NCHARS (int)(sizeof(g_chars)/sizeof(g_chars[0]))
static void* g_items_cache[NCHARS] = {0};   // puntero de item por personaje (resuelto una vez)
static int   g_cyc_idx = 0;

// Catalogo dinamico de personajes descubiertos en memoria en runtime (hasta 256)
typedef struct { char name[64]; DWORD sku; void* item; } dyn_char_t;
#define MAX_DYN_CHARS 256
static dyn_char_t g_dyn_chars[MAX_DYN_CHARS];
static int g_dyn_count = 0;

// resuelve sku -> puntero del item de catalogo (escaneo)
static void* resolve_item_ptr(DWORD sku){
    MEMORY_BASIC_INFORMATION mbi;
    BYTE* p = 0;
    while(VirtualQuery(p, &mbi, sizeof(mbi)) == sizeof(mbi)){
        BYTE* region = (BYTE*)mbi.BaseAddress;
        SIZE_T sz = mbi.RegionSize;
        if(mbi.State==MEM_COMMIT && !(mbi.Protect & (PAGE_GUARD|PAGE_NOACCESS)) &&
           (mbi.Protect==PAGE_READWRITE || mbi.Protect==PAGE_WRITECOPY)){
            BYTE* it;
            for(it = region; it + 0xE0 <= region + sz; it += 4){
                if(*(DWORD*)(it + 0xC8) == sku){
                    DWORD nameptr = *(DWORD*)(it + 0xD0);
                    if(nameptr > 0x10000){
                        MEMORY_BASIC_INFORMATION m2;
                        if(VirtualQuery((void*)nameptr, &m2, sizeof(m2))==sizeof(m2) &&
                           m2.State==MEM_COMMIT && !(m2.Protect & (PAGE_GUARD|PAGE_NOACCESS))){
                            BYTE c0 = *(BYTE*)nameptr;
                            if(c0 >= 0x20 && c0 < 0x7f) return it;   // item valido
                        }
                    }
                }
            }
        }
        p = region + sz;
    }
    return 0;
}

// resuelve personajes en memoria (predefinidos + catalogo dinamico completo)
static void prescan_items(void){
    MEMORY_BASIC_INFORMATION mbi;
    BYTE* p = 0;
    g_dyn_count = 0;
    while(VirtualQuery(p, &mbi, sizeof(mbi)) == sizeof(mbi)){
        BYTE* region = (BYTE*)mbi.BaseAddress;
        SIZE_T sz = mbi.RegionSize;
        if(mbi.State==MEM_COMMIT && !(mbi.Protect & (PAGE_GUARD|PAGE_NOACCESS)) &&
           (mbi.Protect==PAGE_READWRITE || mbi.Protect==PAGE_WRITECOPY)){
            BYTE* it;
            for(it = region; it + 0xE0 <= region + sz; it += 4){
                DWORD sku = *(DWORD*)(it + 0xC8);
                if(sku >= 0xf4000 && sku < 0xf6000){
                    DWORD nameptr = *(DWORD*)(it + 0xD0);
                    if(nameptr > 0x10000 && mem_ok((void*)nameptr, 1, 0) &&
                       (*(BYTE*)nameptr) >= 0x20 && (*(BYTE*)nameptr) < 0x7f){
                        for(int i=0;i<NCHARS;i++){
                            if(!g_items_cache[i] && g_chars[i].sku==sku){ g_items_cache[i]=it; break; }
                        }
                        if(g_dyn_count < MAX_DYN_CHARS){
                            int exists = 0;
                            for(int d=0; d<g_dyn_count; d++){
                                if(g_dyn_chars[d].sku == sku){ exists = 1; break; }
                            }
                            if(!exists){
                                g_dyn_chars[g_dyn_count].sku = sku;
                                g_dyn_chars[g_dyn_count].item = it;
                                lstrcpynA(g_dyn_chars[g_dyn_count].name, (char*)nameptr, 64);
                                g_dyn_count++;
                            }
                        }
                    }
                }
            }
        }
        p = region + sz;
    }
    int found=0; for(int i=0;i<NCHARS;i++) if(g_items_cache[i]) found++;
    L("[coop] cambiador: %d/%d personajes predefinidos | catalogo dinamico: %d personajes descubiertos", found, NCHARS, g_dyn_count);
}

#define P2_SKU_DEFAULT 0xf431d   // Mickey (por defecto)
#define POSX   0x10000
static DWORD g_p2_sku = P2_SKU_DEFAULT;

// Lee el SKU del personaje de P2 desde coop_p2.txt (junto al DLL).
static void read_p2_sku(void){
    char path[MAX_PATH];
    lstrcpynA(path, g_log, MAX_PATH);
    char* p = strrchr(path, '\\');
    if(p) strcpy(p+1, "coop_p2.txt"); else strcpy(path, "coop_p2.txt");
    FILE* f = fopen(path, "r");
    if(!f){ L("[coop] sin coop_p2.txt -> P2 = Mickey (0x%x)", g_p2_sku); return; }
    char buf[64] = {0};
    if(fgets(buf, sizeof(buf), f)){
        unsigned long v = strtoul(buf, NULL, 16);
        if(v != 0 && v != 0xfffffffful) g_p2_sku = (DWORD)v;
    }
    fclose(f);
    L("[coop] P2 SKU (coop_p2.txt) = 0x%x", g_p2_sku);
}

// ---- infra de hooks inline (trampolin) ----
void* g_tramp_e01890 = 0;
void* g_tramp_solidify = 0;
void* g_tramp_set_char = 0;
void* g_tramp_act_changes = 0;

static void* install_hook(void* target, void* detour, int copylen){
    BYTE* tramp = (BYTE*)VirtualAlloc(0, copylen + 5, MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if(!tramp) return 0;
    memcpy(tramp, target, copylen);
    tramp[copylen] = 0xE9;
    *(DWORD*)(tramp + copylen + 1) = (DWORD)((BYTE*)target + copylen) - (DWORD)(tramp + copylen + 5);
    DWORD old;
    VirtualProtect(target, copylen, PAGE_EXECUTE_READWRITE, &old);
    ((BYTE*)target)[0] = 0xE9;
    *(DWORD*)((BYTE*)target + 1) = (DWORD)detour - ((DWORD)target + 5);
    for(int i=5;i<copylen;i++) ((BYTE*)target)[i] = 0x90;
    VirtualProtect(target, copylen, old, &old);
    FlushInstructionCache(GetCurrentProcess(), target, copylen);
    return tramp;
}

// ---- HOOK UNIVERSAL PARA ACTIVACION DE PERSONAJE (FUN_00b73060) ----
void __thiscall hooked_b73060(void* self, int playerId, void* itemOrSku, int force){
    if(!self || !itemOrSku) return;

    DWORD sku = (DWORD)itemOrSku;
    if(sku >= 0x1000000 && mem_ok((void*)sku, 0xD0, 0)){
        sku = *(DWORD*)((BYTE*)sku + 0xC8);
    }

    if(playerId == 0){
        L("[coop] b73060 Player 1: itemOrSku=%p (sku=0x%x) force=%d", itemOrSku, sku, force);
        if(sku >= 0x10000 && sku <= 0xFFFFF){
            if(g_p1_sku != 0 && sku != g_p1_sku){
                g_p1_sku = sku;
                g_p1_pending_sku = 0;
                g_p1_swap_pending = 1;
                L("[coop] P1 SKU changed to 0x%x -> unfreeze requested", sku);
            } else {
                g_p1_sku = sku;
                g_p1_pending_sku = 0;
                L("[coop] P1 SKU unchanged (0x%x) -> manager remains frozen", sku);
            }
        }
        if(g_orig_b73060) g_orig_b73060(self, 0, itemOrSku, force);
        return;
    }

    L("[coop] b73060 Player 2: itemOrSku=%p (sku=0x%x) force=%d", itemOrSku, sku, force);

    if(sku >= 0x10000 && sku <= 0xFFFFF){
        g_p2_sku = sku;
        g_p2_pending_sku = 0;
        g_p2_item = resolve_item_ptr(sku);
        g_p2_swap_pending = 1;
        L("[coop] Menu P2: nuevo sku 0x%x -> materializacion solicitada", g_p2_sku);
    }
    // NOTA DE SEGURIDAD CRITICA:
    // Para playerId=1 NO llamamos a g_orig_b73060 porque en el motor original de PC
    // la funcion tiene cableado fijo playerId=0 y sobreescribiria al Player 1.
}

// ---- HOOKS DE MONITOREO Y PEDESTAL DE UI (VirtualReaderPC) ----
typedef int (__thiscall *get_char_fn_t)(void* self, void* L_state);
static get_char_fn_t g_orig_get_char = NULL;
static void* g_tramp_get_char = 0;

int __thiscall hooked_GetCurrentCharacter(void* self, void* L_state){
    typedef int (*lua_tointeger_t)(void* L, int idx);
    void* base = game_base();
    lua_tointeger_t toint = (lua_tointeger_t)((BYTE*)base + 0xF0F190);
    int pId = (toint && L_state) ? toint(L_state, 1) : 0;
    DWORD saved = 0;
    int swapped = 0;
    if(self && mem_ok(self, 0xC0, 1)){
        saved = *(DWORD*)((BYTE*)self + 0xB0);
        DWORD target_sku = 0;
        if(pId == 0){
            if(g_p1_sku == 0 && saved >= 0x10000 && saved <= 0xFFFFF){
                g_p1_sku = saved;
                L("[ui] P1 SKU inicial aprendido desde self+0xB0: 0x%x", g_p1_sku);
            }
            target_sku = (g_p1_pending_sku != 0) ? g_p1_pending_sku : g_p1_sku;
        } else if(pId == 1){
            target_sku = (g_p2_pending_sku != 0) ? g_p2_pending_sku : g_p2_sku;
        }
        if(target_sku != 0){
            *(DWORD*)((BYTE*)self + 0xB0) = target_sku;
            swapped = 1;
            L("[ui] GetCurrentCharacter(%d): usando sku 0x%x (saved=0x%x, pending=0x%x)",
              pId, target_sku, saved, (pId == 1 ? g_p2_pending_sku : g_p1_pending_sku));
        }
    }
    int res = g_orig_get_char ? g_orig_get_char(self, L_state) : 0;
    if(swapped && self && mem_ok(self, 0xC0, 1)){
        *(DWORD*)((BYTE*)self + 0xB0) = saved;
    }
    return res;
}
typedef int (__thiscall *set_char_fn_t)(void* self, void* L_state);
static set_char_fn_t g_orig_set_char = NULL;

int __thiscall hooked_SetCurrentCharacter(void* self, void* L_state){
    typedef int (*lua_tointeger_t)(void* L, int idx);
    void* base = game_base();
    lua_tointeger_t toint = (lua_tointeger_t)((BYTE*)base + 0xF0F190);
    int pId = (toint && L_state) ? toint(L_state, 2) : 0;
    int res = g_orig_set_char ? g_orig_set_char(self, L_state) : 0;
    if(self && mem_ok(self, 0xC0, 0)){
        DWORD sku = *(DWORD*)((BYTE*)self + 0xB0);
        L("[ui] SetCurrentCharacter: player %d, sku=0x%x", pId, sku);
        if(sku >= 0x10000 && sku <= 0xFFFFF){
            if(pId == 0){
                g_p1_pending_sku = sku;
                L("[ui] P1 pending sku registrado: 0x%x (actual: 0x%x)", g_p1_pending_sku, g_p1_sku);
            } else if(pId == 1){
                g_p2_pending_sku = sku;
                g_p2_sku = sku;
                g_p2_swap_pending = 1;
                L("[ui] P2 pending sku registrado: 0x%x", g_p2_pending_sku);
            }
        }
    }
    return res;
}

typedef int (__thiscall *act_changes_fn_t)(void* self, void* L_state);
static act_changes_fn_t g_orig_act_changes = NULL;

int __thiscall hooked_ActivateChanges(void* self, void* L_state){
    typedef int (*lua_tointeger_t)(void* L, int idx);
    void* base = game_base();
    lua_tointeger_t toint = (lua_tointeger_t)((BYTE*)base + 0xF0F190);
    int pId = (toint && L_state) ? toint(L_state, 1) : 0;
    L("[ui] VirtualReaderPC_ActivateChanges llamado (player %d, self=%p)", pId, self);

    DWORD target_sku = 0;
    if(self && mem_ok(self, 0xC0, 1)){
        if(pId == 0){
            target_sku = (g_p1_pending_sku != 0) ? g_p1_pending_sku : g_p1_sku;
        } else if(pId == 1){
            target_sku = (g_p2_pending_sku != 0) ? g_p2_pending_sku : g_p2_sku;
        }
        if(target_sku != 0){
            *(DWORD*)((BYTE*)self + 0xB0) = target_sku;
            L("[ui] VirtualReaderPC_ActivateChanges: set self+0xB0 = 0x%x for player %d", target_sku, pId);
        }
    }

    if(pId == 0){
        if(g_p1_pending_sku != 0 && g_p1_pending_sku != g_p1_sku){
            g_p1_swap_pending = 1;
            L("[ui] P1 swap pending set: 0x%x -> 0x%x", g_p1_sku, g_p1_pending_sku);
            g_p1_sku = g_p1_pending_sku;
        } else {
            L("[ui] P1 SKU unchanged (current=0x%x, pending=0x%x) -> manager remains frozen", g_p1_sku, g_p1_pending_sku);
        }
    }

    int res = g_orig_act_changes ? g_orig_act_changes(self, L_state) : 0;
    L("[ui] VirtualReaderPC_ActivateChanges completado -> res=%d", res);

    if(pId == 0){
        g_p1_pending_sku = 0;
    } else if(pId == 1){
        g_p2_pending_sku = 0;
    }
    return res;
}

// ---- materializacion y proteccion de estado (dentro de e01890, mgr=ecx) ----
static int g_frames = 0, g_newHandle = 0, g_joinMsg = 0;
static void* s_prev_mgr = NULL;

// ---- HOOK PARA SALIDA LIMPIA DE JUGADOR 2 (RemovePlayer) ----
typedef int (__thiscall *rem_player_fn_t)(void* self, void* L_state);
static rem_player_fn_t g_orig_rem_player = NULL;
static void* g_tramp_rem_player = 0;

int __thiscall hooked_RemovePlayer(void* self, void* L_state){
    typedef int (*lua_tointeger_t)(void* L, int idx);
    void* base = game_base();
    lua_tointeger_t toint = (lua_tointeger_t)((BYTE*)base + 0xF0F190);
    int pId = (toint && L_state) ? toint(L_state, 1) : -1;
    L("[coop] RemovePlayer llamado para player %d (g_active era %d)", pId, g_active);
    if(pId == 1){
        g_active = 0;
        g_coop_done = 0;
        g_frames = 0;
        g_newHandle = 0;
        g_joinMsg = 0;
        g_p2_current_item = NULL;
        g_p2_swap_pending = 0;
        g_p2_pending_sku = 0;
        g_p2_avatar = NULL;
        g_p1_swap_pending = 0;
        g_p1_swap_frames = 0;
        L("[coop] P2 ha salido -> co-op reseteado limpiamente");
    }
    return g_orig_rem_player ? g_orig_rem_player(self, L_state) : 0;
}


void on_e01890(void* mgr){
    if(!g_active || !mgr) return;
    void* base = game_base();

    // Comprobacion de salida de partida / cambio de nivel (gameloop o manager invalidos)
    void* loop = find_gameloop(base);
    void* g = *(void**)((BYTE*)base + 0x1E5F540);          // gCountPtr -> g
    if(!loop || !g || !mem_ok(g, 0x100, 0)){
        if(g_active){
            L("[coop] fin de partida / transicion detectada (loop=%p, g=%p) -> reseteando co-op", loop, g);
            g_active = 0;
            g_coop_done = 0;
            g_frames = 0;
            g_newHandle = 0;
            g_joinMsg = 0;
            g_p2_current_item = NULL;
            s_prev_mgr = NULL;
            g_p2_swap_pending = 0;
            g_p2_avatar = NULL;
            g_p1_swap_pending = 0;
            g_p1_swap_frames = 0;
        }
        return;
    }

    // Si el manager de virtual reader cambio (reinicio de mundo o nuevo nivel)
    if(s_prev_mgr != NULL && s_prev_mgr != mgr){
        L("[coop] nuevo virtual reader manager (%p != %p) -> reseteando co-op", mgr, s_prev_mgr);
        g_active = 0;
        g_coop_done = 0;
        g_frames = 0;
        g_newHandle = 0;
        g_joinMsg = 0;
        g_p2_current_item = NULL;
        s_prev_mgr = mgr;
        g_p2_swap_pending = 0;
        g_p2_avatar = NULL;
        g_p1_swap_pending = 0;
        g_p1_swap_frames = 0;
        return;
    }
    s_prev_mgr = mgr;

    // RE-MATERIALIZACION TRAS SWAP DE PERSONAJE P1 (desde menu picker):
    if(g_p1_swap_pending){
        g_p1_swap_pending = 0;
        g_p1_swap_frames = 15;
        L("[coop] P1 swap pending -> descongelando mgr por 15 frames (P1 sku 0x%x)", g_p1_sku);
    }

    // RE-MATERIALIZACION TRAS SWAP DE PERSONAJE P2 (desde LB+RB o menu picker):
    if(g_p2_swap_pending){
        g_p2_swap_pending = 0;
        g_frames = 0;
        g_newHandle = 0;
        g_joinMsg = 0;
        if(mem_ok(mgr, 0x890, 1)){
            *(DWORD*)((BYTE*)mgr + 0x64) = 0;      // borrar handle -> fuerza al motor a re-spawnear
            *((BYTE*)mgr + 0x845) = 0;             // des-congelar
            *((BYTE*)mgr + 0x83a) = 1;             // solicitar union / spawn
            void* pA = *(void**)((BYTE*)mgr + 0xC); // Slot 1 (Player 2)
            if(pA && mem_ok(pA, 0x60, 1)){
                *(DWORD*)((BYTE*)pA + 0x10) = g_p2_sku;
                *(DWORD*)((BYTE*)pA + 0x58) = POSX;
                *(DWORD*)((BYTE*)pA + 0x5C) = 0;
            }
        }
        L("[coop] re-materializando P2 (nuevo personaje sku 0x%x)...", g_p2_sku);
    }

    // Mantener a P2 solido en cada frame (evita que se vuelva fantasma si P1 cambia personaje)
    if(g_p2_avatar && mem_ok(g_p2_avatar, 0x40, 1)){
        *((BYTE*)g_p2_avatar + 0x39) &= ~2;
    }

    // Mantener player count en 2 mientras co-op siga activo en partida
    if(*(DWORD*)((BYTE*)g + 0x94) < 2) *(DWORD*)((BYTE*)g + 0x94) = 2;

    g_frames++;
    *(DWORD*)((BYTE*)base + 0x1E0191C) = 1;               // introFlag

    // Mantener sincronizado el SKU de P2 en su slot de base virtual
    void* pA = (mem_ok(mgr, 0x10, 0)) ? *(void**)((BYTE*)mgr + 0xC) : NULL;
    if(pA && mem_ok(pA, 0x20, 1)){
        *(DWORD*)((BYTE*)pA + 0x10) = g_p2_sku;
    }
    // NOTA DE SEGURIDAD CRITICA: NUNCA escribir en pB (Slot 0 / Player 1).

    if(g_newHandle == 0 && mem_ok(mgr, 0x70, 0)){
        DWORD hx = *(DWORD*)((BYTE*)mgr + 0x64);
        if(hx > 0x100000 && hx != 0xffffffff) g_newHandle = hx;
    }

    // FASE INICIAL DE DROP-IN / RE-MATERIALIZACION (~45 frames)
    if(g_newHandle == 0 && g_frames < 45){
        if(pA && mem_ok(pA, 0x60, 1)){
            *(DWORD*)((BYTE*)pA+0x10) = g_p2_sku;
            *(DWORD*)((BYTE*)pA+0x58) = POSX;
            *(DWORD*)((BYTE*)pA+0x5C) = 0;
        }

        if(mem_ok(mgr, 0x890, 1)){
            *((BYTE*)mgr+0x845) = 0; *((BYTE*)mgr+0x880) = 0; *((BYTE*)mgr+0x88c) = 0;
            *((BYTE*)mgr+0x84b) = 0; *((BYTE*)mgr+0x84c) = 0;
            *((BYTE*)mgr+0x867) = 1; *((BYTE*)mgr+0x83a) = 1;
        }

        if(mem_ok(mgr, 0xD0, 0) && *(int*)((BYTE*)mgr+0xcc) == -1 && g){
            void* ctxArr = *(void**)((BYTE*)g + 0x108);
            if(ctxArr && mem_ok(ctxArr, 0x60, 1)){
                void* ctx1 = (BYTE*)ctxArr + 0x50;
                *(DWORD*)((BYTE*)ctx1+0x10) = 1;
                *(DWORD*)((BYTE*)ctx1+0x48) = 1;
                *((BYTE*)ctx1+0x20) = *((BYTE*)ctxArr+0x20);
                *(DWORD*)((BYTE*)mgr+0xcc) = 1;
            }
        }
    } else {
        // FASE SOLIDIFICADA: Nunca re-activar join request
        if(g_p1_swap_frames > 0){
            g_p1_swap_frames--;
            if(mem_ok(mgr, 0x890, 1)){
                *((BYTE*)mgr+0x845) = 0;
            }
            if(g_p1_swap_frames == 0){
                L("[coop] P1 swap unfreeze completado (volviendo a congelar)");
            }
        } else {
            if(mem_ok(mgr, 0x890, 1)){
                *((BYTE*)mgr+0x845) = 1;
                *((BYTE*)mgr+0x83a) = 0;
            }
        }
        if(pA && mem_ok(pA, 0x20, 1)){
            *(DWORD*)((BYTE*)pA + 0x10) = g_p2_sku;
        }
        if(!g_joinMsg){
            g_joinMsg = 1;
            L("[coop] CONGELADO (cuerpo solido). frames=%d", g_frames);
        }
    }
}

// ---- solidificar avatar slot 1 (dentro de 9e9dc0; args en pila) ----
void on_solidify(void* esp){
    DWORD slot = *(DWORD*)((BYTE*)esp + 4);
    void* av   = *(void**)((BYTE*)esp + 8);
    if(slot == 1 && av){
        g_p2_avatar = av;
        BYTE f = *((BYTE*)av + 0x39);
        if(f & 2) *((BYTE*)av + 0x39) = f & 0xFD;
        L("[solidify] on_solidify: P2 avatar registrado: %p (flags=0x%02x)", av, f);
    }
}

__attribute__((naked)) void stub_e01890(void){
    __asm__(
        "pushal\n\t"
        "pushfl\n\t"
        "pushl %ecx\n\t"
        "call _on_e01890\n\t"
        "addl $4, %esp\n\t"
        "popfl\n\t"
        "popal\n\t"
        "jmp *_g_tramp_e01890\n\t"
    );
}
__attribute__((naked)) void stub_solidify(void){
    __asm__(
        "pushal\n\t"
        "pushfl\n\t"
        "leal 36(%esp), %eax\n\t"
        "pushl %eax\n\t"
        "call _on_solidify\n\t"
        "addl $4, %esp\n\t"
        "popfl\n\t"
        "popal\n\t"
        "jmp *_g_tramp_solidify\n\t"
    );
}

static void install_hooks(void* base){
    if(g_hooks_done) return;
    g_tramp_e01890      = install_hook((BYTE*)base + 0xA01890, (void*)stub_e01890, 6);
    g_tramp_solidify    = install_hook((BYTE*)base + 0x9E9DC0, (void*)stub_solidify, 7);
    g_tramp_b73060      = install_hook((BYTE*)base + 0x773060, (void*)hooked_b73060, 6);
    g_orig_b73060       = (b73060_fn_t)g_tramp_b73060;
    g_tramp_get_char    = install_hook((BYTE*)base + 0x77FF90, (void*)hooked_GetCurrentCharacter, 6);
    g_orig_get_char     = (get_char_fn_t)g_tramp_get_char;
    g_tramp_set_char    = install_hook((BYTE*)base + 0x7406E0, (void*)hooked_SetCurrentCharacter, 7);
    g_orig_set_char     = (set_char_fn_t)g_tramp_set_char;
    g_tramp_act_changes = install_hook((BYTE*)base + 0x783D20, (void*)hooked_ActivateChanges, 7);
    g_orig_act_changes  = (act_changes_fn_t)g_tramp_act_changes;
    g_tramp_rem_player  = install_hook((BYTE*)base + 0x73EC80, (void*)hooked_RemovePlayer, 7);
    g_orig_rem_player   = (rem_player_fn_t)g_tramp_rem_player;
    g_hooks_done = 1;
    L("[coop] hooks instalados: e01890=%p solidify=%p b73060=%p getChar=%p setChar=%p actChanges=%p remPlayer=%p",
      g_tramp_e01890, g_tramp_solidify, g_tramp_b73060, g_tramp_get_char, g_tramp_set_char, g_tramp_act_changes, g_tramp_rem_player);
}

static int mem_ok(void* p, SIZE_T n, int write){
    MEMORY_BASIC_INFORMATION mbi;
    if(!p) return 0;
    if(VirtualQuery(p, &mbi, sizeof(mbi)) != sizeof(mbi)) return 0;
    if(mbi.State != MEM_COMMIT) return 0;
    if(mbi.Protect & (PAGE_GUARD|PAGE_NOACCESS)) return 0;
    DWORD pr = mbi.Protect & 0xFF;
    int rd = (pr==PAGE_READONLY||pr==PAGE_READWRITE||pr==PAGE_WRITECOPY||
              pr==PAGE_EXECUTE_READ||pr==PAGE_EXECUTE_READWRITE||pr==PAGE_EXECUTE_WRITECOPY);
    int wr = (pr==PAGE_READWRITE||pr==PAGE_WRITECOPY||
              pr==PAGE_EXECUTE_READWRITE||pr==PAGE_EXECUTE_WRITECOPY);
    if((BYTE*)p + n > (BYTE*)mbi.BaseAddress + mbi.RegionSize) return 0;
    return write ? wr : rd;
}

static void run_coop(void){
    if(g_coop_done) return;
    void* base = game_base();
    L("[coop] base=%p", base);

    void* pOperand = (BYTE*)base + (0x69E3CF + 2);
    if(!mem_ok(pOperand, 4, 0)){ L("[coop] operando @%p no legible", pOperand); return; }
    DWORD opAddr = 0;
    memcpy(&opAddr, pOperand, sizeof(DWORD));
    L("[coop] opAddr(global)=%08x", opAddr);

    if(!mem_ok((void*)opAddr, 4, 0)){ L("[coop] global @%08x no legible (no estas en partida?)", opAddr); return; }
    void* gamePlayers = *(void**)opAddr;
    L("[coop] gamePlayers=%p", gamePlayers);
    if(!mem_ok(gamePlayers, 0x100, 1)){ L("[coop] gamePlayers no escribible -> entra a una Toy Box y reintenta"); return; }

    DWORD pCount = *(DWORD*)((BYTE*)gamePlayers + 0x94);
    if(pCount < 1){
        L("[coop] Player 1 aun no esta en partida (pCount=%d) -> espera a entrar a Toy Box", pCount);
        return;
    }

    *((BYTE*)gamePlayers + 0x98) = 1;
    L("[coop] +0x98=1 OK, buscando gameLoop...");

    void* gameLoop = find_gameloop(base);
    if(!gameLoop){ L("[coop] gameLoop NO encontrado (reintenta con Start)"); return; }
    L("[coop] gameLoop=%p -> DROP-IN", gameLoop);

    read_p2_sku();                       // personaje de P2 desde coop_p2.txt
    install_hooks(base);                 // hooks activos ANTES del drop-in

    dropin_t dropInFn = (dropin_t)((BYTE*)base + 0x69B020);  // RVA (no restar 0x400000)
    *((BYTE*)gamePlayers + 0x98) = 1;
    dropInFn(gameLoop, 1);
    g_coop_done = 1;
    g_active = 1;                         // e01890 empieza a materializar a P2

    L("[coop] drop-in llamado + materializacion ON. P2 solido en ~1s.");

    prescan_items();
    for(int i=0;i<NCHARS;i++) if(g_chars[i].sku==g_p2_sku){ g_cyc_idx=i; break; }
    g_p2_item = (g_cyc_idx>=0 && g_items_cache[g_cyc_idx]) ? g_items_cache[g_cyc_idx]
                                                          : resolve_item_ptr(g_p2_sku);
    L("[coop] item inicial de P2 (sku 0x%x) = %p", g_p2_sku, g_p2_item);
}
// =========================================================================

typedef DWORD (WINAPI *XInputGetState_t)(DWORD, void*);
static XInputGetState_t pXI = NULL;

static void load_xinput(void){
    const char* dlls[] = {"xinput1_4.dll","xinput1_3.dll","xinput9_1_0.dll","xinput1_2.dll","xinput1_1.dll"};
    for(int i=0;i<5;i++){
        HMODULE m = LoadLibraryA(dlls[i]);
        if(m){ pXI = (XInputGetState_t)GetProcAddress(m, "XInputGetState");
               if(pXI){ L("[xinput] %s", dlls[i]); return; } }
    }
    L("[xinput] NO encontrado");
}

static void coop_trigger(void){
    if(!g_coop_done){
        L("[coop] START en mando 2 -> lanzando secuencia co-op");
        run_coop();
    }
}

static void cycle_p2_character(int direction){
    for(int k=0; k<NCHARS; k++){
        g_cyc_idx = (g_cyc_idx + direction) % NCHARS;
        if(g_cyc_idx < 0) g_cyc_idx += NCHARS;
        if(g_items_cache[g_cyc_idx] || 1){
            g_p2_sku  = g_chars[g_cyc_idx].sku;
            g_p2_item = g_items_cache[g_cyc_idx];
            g_p2_pending_sku = 0;
            g_p2_swap_pending = 1; // Delegar al hilo principal
            L("[input] cambiar P2 -> %s (0x%x) [%d/%d] (delegado a main thread)",
              g_chars[g_cyc_idx].name, g_chars[g_cyc_idx].sku, g_cyc_idx + 1, NCHARS);
            break;
        }
    }
}

static DWORD WINAPI worker(LPVOID unused){
    (void)unused;
    Sleep(1500);
    L("=== DI3 co-op mod cargado (proxy bink2w32) ===");
    load_xinput();
    BYTE prev[4] = {0,0,0,0};
    BYTE prevCyc[4] = {0,0,0,0};
    for(;;){
        if(pXI){
            for(DWORD pad=0; pad<4; pad++){
                BYTE st[16];
                if(pXI(pad, st) == ERROR_SUCCESS){
                    WORD b = *(WORD*)(st+4);
                    BYTE now = (b & XI_START) ? 1 : 0;
                    if(now && !prev[pad]){
                        L("[input] START en pad %lu", pad);
                        if(pad == 1) coop_trigger();
                    }
                    prev[pad] = now;

                    // CAMBIADOR de personaje de P2 en mando 2 (pad 1):
                    // - LB + RB  o  LB + D-Pad Derecha: Siguiente personaje
                    // - LB + D-Pad Izquierda: Personaje anterior
                    // - LB + BACK: Recargar personaje desde coop_p2.txt
                    BYTE cycNext = (((b & 0x0300) == 0x0300) || ((b & 0x0108) == 0x0108)) ? 1 : 0;
                    BYTE cycPrev = ((b & 0x0104) == 0x0104) ? 1 : 0;
                    BYTE cycReload = ((b & 0x0120) == 0x0120) ? 1 : 0;

                    if(pad == 1 && g_active && !g_p2_swap_pending){
                        if(cycNext && !prevCyc[pad]){
                            cycle_p2_character(1);
                        } else if(cycPrev && !prevCyc[pad]){
                            cycle_p2_character(-1);
                        } else if(cycReload && !prevCyc[pad]){
                            read_p2_sku();
                            g_p2_item = resolve_item_ptr(g_p2_sku);
                            g_p2_swap_pending = 1;
                            L("[input] P2 recargado desde coop_p2.txt: sku 0x%x (delegado a main thread)", g_p2_sku);
                        }
                    }
                    prevCyc[pad] = (cycNext || cycPrev || cycReload);
                }
            }
        }
        Sleep(25);
    }
    return 0;
}

static LONG WINAPI CrashHandler(PEXCEPTION_POINTERS pExcept){
    if(pExcept && pExcept->ExceptionRecord){
        DWORD code = pExcept->ExceptionRecord->ExceptionCode;
        if(code == 0xC0000005 || code == 0xC000001D || code == 0x80000003 || code == 0xC0000025){
            PEXCEPTION_RECORD r = pExcept->ExceptionRecord;
            PCONTEXT c = pExcept->ContextRecord;
            void* base = game_base();
            DWORD rva = (DWORD)r->ExceptionAddress - (DWORD)base;
            L("[CRASH] Exception %08X at %p (base+%08X, Ghidra 0x%08X)",
              code, r->ExceptionAddress, rva, rva + 0x400000);
            if(code == 0xC0000005){
                L("[CRASH] Op: %s addr=%p",
                  r->ExceptionInformation[0] == 0 ? "READ" : (r->ExceptionInformation[0] == 1 ? "WRITE" : "EXEC"),
                  (void*)r->ExceptionInformation[1]);
            }
            if(c){
                L("[CRASH] EAX=%08X EBX=%08X ECX=%08X EDX=%08X", c->Eax, c->Ebx, c->Ecx, c->Edx);
                L("[CRASH] ESI=%08X EDI=%08X EBP=%08X ESP=%08X", c->Esi, c->Edi, c->Ebp, c->Esp);
            }
        }
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r){
    (void)r;
    if(reason == DLL_PROCESS_ATTACH){
        g_self = h;
        GetModuleFileNameA(h, g_log, MAX_PATH);
        char* p = strrchr(g_log, '\\');
        if(p) strcpy(p+1, "di3_coop.log"); else strcpy(g_log, "di3_coop.log");
        DeleteFileA(g_log);
        DisableThreadLibraryCalls(h);
        AddVectoredExceptionHandler(1, CrashHandler);
        CreateThread(NULL, 0, worker, NULL, 0, NULL);
    }
    return TRUE;
}
