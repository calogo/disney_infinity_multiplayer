@echo off
REM Uninstaller: restores original files.
setlocal
cd /d "%~dp0"

if not exist "bink2w32_orig.dll" (
  echo No backup ^(bink2w32_orig.dll^) found. The mod DLL may not be installed.
) else (
  if exist "bink2w32.dll" del /Q "bink2w32.dll"
  ren "bink2w32_orig.dll" "bink2w32.dll"
  echo [OK] Original bink2w32.dll restored.
)

REM Restore original presentation UI scripts
if exist "assets\presentation" (
  for %%F in (container.lua virtualreaderpc_gridcharacter.lua virtualreaderpc_gridbase.lua virtualreaderpc_loadout.lua virtualreaderpc_tabs.lua virtualreaderpc_characterinspect.lua virtualreaderpc_coreabilities.lua upsellpc.lua virtualreaderpc.lua) do (
    if exist "assets\presentation\%%F.coop_orig" (
      copy /Y "assets\presentation\%%F.coop_orig" "assets\presentation\%%F" >nul
      del /Q "assets\presentation\%%F.coop_orig" >nul
    )
  )
  echo [OK] Original presentation UI scripts restored.
)

echo.
echo [OK] Mod uninstalled.
pause
